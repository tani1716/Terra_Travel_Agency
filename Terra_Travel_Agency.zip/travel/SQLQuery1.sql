﻿ALTER TABLE TrainBooking_tbl
ADD TotalAmount DECIMAL(18, 2) NOT NULL;
