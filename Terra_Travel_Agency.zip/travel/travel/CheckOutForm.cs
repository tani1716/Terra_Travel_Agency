﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class CheckOutForm : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";



        public CheckOutForm()
        {
            InitializeComponent();
            LoadCustomerIDs(); // Load available customer IDs on form load
        }

        private void FetchBookingDetails()
        {
            string customerID = cmbCustomerID.SelectedItem.ToString(); // Get selected CustomerID from ComboBox
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // SQL query to get customer, hotel booking, and hotel info
                string query = "SELECT c.Name, hb.HotelName, hb.CheckInDate, hb.CheckOutDate, hi.PricePerNight " +
                               "FROM HotelBookings_tbl hb " +
                               "INNER JOIN CustomerForm_tbl c ON hb.CustomerID = c.CustomerId " +
                               "INNER JOIN Hotels_info_tbl hi ON hb.HotelName = hi.HotelName " +
                               "WHERE hb.CustomerID = " + customerID;

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Fill form fields with retrieved data
                    txtCustomerName.Text = reader["Name"].ToString();
                    txtHotelName.Text = reader["HotelName"].ToString();
                    txtCheckInDate.Text = Convert.ToDateTime(reader["CheckInDate"]).ToString("yyyy-MM-dd");
                    txtCheckOutDate.Text = Convert.ToDateTime(reader["CheckOutDate"]).ToString("yyyy-MM-dd");
                    txtPricePerNight.Text = reader["PricePerNight"].ToString();

                    CalculateTotalDaysAndAmount(); // Automatically calculate total days and total amount
                }
            }
        }


        // Method to load Customer IDs into ComboBox
        private void LoadCustomerIDs()
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT CustomerID FROM HotelBookings_tbl";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cmbCustomerID.Items.Add(reader["CustomerID"].ToString());
                }
            }
        }





        private void CheckOutForm_Load(object sender, EventArgs e)
        {


        }


        // Method to calculate total days and total amount
        private void CalculateTotalDaysAndAmount()
        {
            if (DateTime.TryParse(txtCheckInDate.Text, out DateTime checkInDate) &&
                DateTime.TryParse(txtCheckOutDate.Text, out DateTime checkOutDate))
            {
                // Calculate total days between Check-In and Check-Out
                int totalDays = (checkOutDate - checkInDate).Days;
                txtTotalDays.Text = totalDays.ToString();

                // Calculate total amount: Price Per Night * Total Days
                if (decimal.TryParse(txtPricePerNight.Text, out decimal pricePerNight))
                {
                    decimal totalAmount = pricePerNight * totalDays;
                    txtTotalAmount.Text = totalAmount.ToString("F2");
                }
            }
        }



        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Insert checkout details into CheckOut_tbl
                string query = "INSERT INTO CheckOut_tbl (CustomerName, HotelName, CheckInDate, CheckOutDate, TotalAmount) " +
                               "VALUES ('" + txtCustomerName.Text + "', '" + txtHotelName.Text + "', '" + txtCheckInDate.Text +
                               "', '" + txtCheckOutDate.Text + "', '" + txtTotalAmount.Text + "')";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                MessageBox.Show("Check-Out successful!");
            }

        }

        private void cmbCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            // string customerID = cmbCustomerID.SelectedItem.ToString();
            FetchBookingDetails(); // Fetch booking details based on selected CustomerID
        }

        private void txtCheckOutDate_TextChanged(object sender, EventArgs e)
        {
            CalculateTotalDaysAndAmount();

        }
    }
}