﻿
namespace travel
{
    partial class BookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTrainBooking = new System.Windows.Forms.Button();
            this.btnHotelBooking = new System.Windows.Forms.Button();
            this.btnCancelBooking = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.payment = new System.Windows.Forms.Label();
            this.hotel = new System.Windows.Forms.Label();
            this.train = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.hotelbook = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnTrainBooking
            // 
            this.btnTrainBooking.BackColor = System.Drawing.Color.Tomato;
            this.btnTrainBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainBooking.Location = new System.Drawing.Point(359, 126);
            this.btnTrainBooking.Name = "btnTrainBooking";
            this.btnTrainBooking.Size = new System.Drawing.Size(406, 118);
            this.btnTrainBooking.TabIndex = 3;
            this.btnTrainBooking.Text = "TRAIN BOOKING";
            this.btnTrainBooking.UseVisualStyleBackColor = false;
            this.btnTrainBooking.Click += new System.EventHandler(this.btnTrainBooking_Click_1);
            // 
            // btnHotelBooking
            // 
            this.btnHotelBooking.BackColor = System.Drawing.Color.Tomato;
            this.btnHotelBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHotelBooking.Location = new System.Drawing.Point(727, 321);
            this.btnHotelBooking.Name = "btnHotelBooking";
            this.btnHotelBooking.Size = new System.Drawing.Size(408, 118);
            this.btnHotelBooking.TabIndex = 4;
            this.btnHotelBooking.Text = "HOTEL BOOKING";
            this.btnHotelBooking.UseVisualStyleBackColor = false;
            this.btnHotelBooking.Click += new System.EventHandler(this.btnHotelBooking_Click);
            // 
            // btnCancelBooking
            // 
            this.btnCancelBooking.BackColor = System.Drawing.Color.Tomato;
            this.btnCancelBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelBooking.Location = new System.Drawing.Point(464, 506);
            this.btnCancelBooking.Name = "btnCancelBooking";
            this.btnCancelBooking.Size = new System.Drawing.Size(431, 113);
            this.btnCancelBooking.TabIndex = 5;
            this.btnCancelBooking.Text = "CANCEL BOOKING";
            this.btnCancelBooking.UseVisualStyleBackColor = false;
            this.btnCancelBooking.Click += new System.EventHandler(this.btnCancelBooking_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 607);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 17);
            this.label5.TabIndex = 71;
            this.label5.Text = "logout";
            // 
            // payment
            // 
            this.payment.AutoSize = true;
            this.payment.Location = new System.Drawing.Point(89, 506);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(74, 17);
            this.payment.TabIndex = 70;
            this.payment.Text = "PAYMENT";
            // 
            // hotel
            // 
            this.hotel.AutoSize = true;
            this.hotel.Location = new System.Drawing.Point(89, 411);
            this.hotel.Name = "hotel";
            this.hotel.Size = new System.Drawing.Size(123, 17);
            this.hotel.TabIndex = 69;
            this.hotel.Text = "HOTEL BOOKING";
            // 
            // train
            // 
            this.train.AutoSize = true;
            this.train.Location = new System.Drawing.Point(88, 318);
            this.train.Name = "train";
            this.train.Size = new System.Drawing.Size(117, 17);
            this.train.TabIndex = 68;
            this.train.Text = "TRAIN BOOKING";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 67;
            this.label1.Text = "Login";
            // 
            // hotelbook
            // 
            this.hotelbook.AutoSize = true;
            this.hotelbook.BackColor = System.Drawing.Color.PeachPuff;
            this.hotelbook.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelbook.ForeColor = System.Drawing.Color.LightCoral;
            this.hotelbook.Location = new System.Drawing.Point(523, 31);
            this.hotelbook.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.hotelbook.Name = "hotelbook";
            this.hotelbook.Size = new System.Drawing.Size(311, 69);
            this.hotelbook.TabIndex = 76;
            this.hotelbook.Text = "BOOKING";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::travel.Properties.Resources.back;
            this.pictureBox9.Location = new System.Drawing.Point(1064, 562);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(71, 60);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 75;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::travel.Properties.Resources.hotelmanagement;
            this.pictureBox8.Location = new System.Drawing.Point(359, 283);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(270, 192);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 73;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::travel.Properties.Resources.traveltrain;
            this.pictureBox7.Location = new System.Drawing.Point(865, 95);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(270, 192);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 72;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::travel.Properties.Resources.l1;
            this.pictureBox6.Location = new System.Drawing.Point(12, 591);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 66;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::travel.Properties.Resources.pay;
            this.pictureBox5.Location = new System.Drawing.Point(11, 486);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 65;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::travel.Properties.Resources.hotel;
            this.pictureBox4.Location = new System.Drawing.Point(11, 389);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 64;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::travel.Properties.Resources.trainmanage;
            this.pictureBox3.Location = new System.Drawing.Point(11, 296);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 63;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::travel.Properties.Resources.login1;
            this.pictureBox2.Location = new System.Drawing.Point(12, 194);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 62;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::travel.Properties.Resources.Travel_agency__1__removebg_preview__2_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(159, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 61;
            this.pictureBox1.TabStop = false;
            // 
            // BookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.hotelbook);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.hotel);
            this.Controls.Add(this.train);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCancelBooking);
            this.Controls.Add(this.btnHotelBooking);
            this.Controls.Add(this.btnTrainBooking);
            this.Name = "BookingForm";
            this.Text = "BookingForm";
            this.Load += new System.EventHandler(this.BookingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTrainBooking;
        private System.Windows.Forms.Button btnHotelBooking;
        private System.Windows.Forms.Button btnCancelBooking;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label payment;
        private System.Windows.Forms.Label hotel;
        private System.Windows.Forms.Label train;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label hotelbook;
    }
}