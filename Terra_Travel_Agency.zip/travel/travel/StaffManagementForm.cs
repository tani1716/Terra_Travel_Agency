﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace travel
{
    public partial class StaffManagementForm : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";
        int selectedId = -1;

        public StaffManagementForm()
        {
            InitializeComponent();
        }
        void connection()
        {
            con = new SqlConnection(connectionString);
            con.Open();
        }

        void LoadStaffData()
        {
            using (con = new SqlConnection(connectionString))
            {
                da = new SqlDataAdapter("SELECT StaffID, sname, position, PhoneNumber, semail FROM Staff_info_tbl", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewStaff.DataSource = dt;
            }
        }


        private void StaffManagementForm_Load(object sender, EventArgs e)
        {
            LoadStaffData();
        }

        private void btnAddStaff_Click(object sender, EventArgs e)
        {

            string query = "INSERT INTO Staff_info_tbl (sname, position, PhoneNumber, semail) " +
                            "VALUES ('" + txtStaffName.Text + "', '" + txtPosition.Text + "', '" + txtPhoneNumber.Text + "', '" + txtEmail.Text + "')";


            using (con = new SqlConnection(connectionString))
            {
                con.Open();
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
                LoadStaffData();

            }
        }
        private void btnUpdateStaff_Click(object sender, EventArgs e)
        {
            UpdateRecord();
        }

        void UpdateRecord()
        {
            if (selectedId != -1)
            {
                // Open the connection before executing the update
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Staff_info_tbl SET sname = '" + txtStaffName.Text + "', position = '" + txtPosition.Text +
                                   "', PhoneNumber = '" + txtPhoneNumber.Text + "', semail = '" + txtEmail.Text + "' WHERE StaffID = " + selectedId;

                    SqlCommand cmd = new SqlCommand(query, connection);

                    connection.Open(); // Open the connection here

                    cmd.ExecuteNonQuery(); // Execute the update command
                }

                LoadStaffData(); // Refresh the data after update
            }
            else
            {
                MessageBox.Show("No record selected for update.");
            }
        }

        void DeleteRecord()
        {
            if (selectedId != -1)
            {

                string query = "DELETE FROM Staff_info_tbl WHERE StaffID = " + selectedId;

                using (con = new SqlConnection(connectionString))
                {
                    con.Open();
                   cmd = new SqlCommand(query, con);


                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                MessageBox.Show("Record deleted successfully.");
                LoadStaffData();

            }
            else
            {
                MessageBox.Show("No record selected for deletion. Please select a record first.");
            }
        }

        public DataTable GetAllStaff()
        {
            DataTable staffTable = new DataTable(); // Create a table to store staff data
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Staff_info_tbl"; // SQL command to get all staff records
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(staffTable); // Fill the table with data from the database
            }
            return staffTable; // Return the table with all staff data
        }

        private void btnViewAllStaff_Click(object sender, EventArgs e)
        {
            LoadStaffData();
        }

        private void dataGridViewStaff_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void dataGridViewStaff_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridViewStaff.Rows.Count)
            {
                DataGridViewRow row = dataGridViewStaff.Rows[e.RowIndex];
                selectedId = Convert.ToInt32(row.Cells["StaffID"].Value);
                txtStaffName.Text = row.Cells["sname"].Value.ToString();
                txtPosition.Text = row.Cells["position"].Value.ToString();
                txtPhoneNumber.Text = row.Cells["PhoneNumber"].Value.ToString();
                txtEmail.Text = row.Cells["semail"].Value.ToString();
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            DeleteRecord();
        }
    }

}