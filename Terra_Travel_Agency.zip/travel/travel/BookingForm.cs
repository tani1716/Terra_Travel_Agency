﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class BookingForm : Form
    {
        //string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";


        private DataAccess dataAccess = new DataAccess(); // Ensure this is correct
        public BookingForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new HotelBookingForm().Show();

        }

       /* private void LoadBookingData()
        {
            string query = "SELECT BookingID, CustomerName, BookingType, BookingDate, Status FROM BookingForm_tbl"; // Adjust the query if needed

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the data to the DataGridView
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }*/

        private void BookingForm_Load(object sender, EventArgs e)
        {
          //  LoadBookingData();

            //dataGridView1.AutoGenerateColumns = false;
        }

        private void btnTrainBooking_Click(object sender, EventArgs e)
        {
            new TrainBookingForm().Show();

        }

        private void btnCancelBooking_Click(object sender, EventArgs e)
        {
            new CancellationForm().Show();

        }

        private void btnProceedToCheckout_Click(object sender, EventArgs e)
        {
      
        }

        private void btnTrainBooking_Click_1(object sender, EventArgs e)
        {
            TrainBookingForm trainbooking = new TrainBookingForm();
            trainbooking.Show(); // Show the booking form
            this.Hide(); // Hide the current form
        }

        private void btnCancelBooking_Click_1(object sender, EventArgs e)
        {
            CancellationForm cancellationform = new CancellationForm();
            cancellationform.Show(); // Show the booking form
            this.Hide(); // Hide the current form
        }

        private void btnHotelBooking_Click(object sender, EventArgs e)
        {
            HotelBookingForm hotelbookingform = new HotelBookingForm();
            hotelbookingform.Show(); // Show the booking form
            this.Hide(); // Hide the current form
        }
    }
}