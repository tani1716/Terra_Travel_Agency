﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace travel
{
    public partial class CustomerForm : Form
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";


        public CustomerForm()
        {
            InitializeComponent();

        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadCustomers();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            AddCustomer();

        }

        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            SearchCustomer();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dataGridView1.Columns["Delete"].Index)
            {
                // Get the ID of the customer to delete
                int customerId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["CustomerId"].Value); // Change "Id" to your actual ID column name

                // Call the method to delete the customer
                DeleteCustomer(customerId);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();

        }

        private void DeleteCustomer(int customerId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM CustomerForm_tbl WHERE CustomerId = " + customerId; // Change "Id" to your actual ID column name

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Customer deleted successfully.");
                        LoadCustomers(); // Refresh the DataGridView after deletion
                    }
                    else
                    {
                        MessageBox.Show("Error deleting customer.");
                    }
                }
            }
        }




        private void AddCustomer()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Get values from text boxes
                string NameValue = txtName.Text;
                string EmailValue = txtEmail.Text;
                string PhoneValue = txtPhone.Text;
                string AddressValue = txtAddress.Text;

                // Construct the insert query
                string query = "INSERT INTO CustomerForm_tbl (Name, Email, Phone, Address) " +
                               "VALUES ('" + NameValue + "', '" + EmailValue + "', '" + PhoneValue + "', '" + AddressValue + "')";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Customer added successfully.");
                        LoadCustomers(); // Call to refresh the DataGridView
                    }
                    else
                    {
                        MessageBox.Show("Error adding customer.");
                    }
                }
            }
        }


        private void ClearFields()
        {
            txtName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
        }
        private void SearchCustomer()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Construct the search value directly in the query string
                string SearchValue = "%" + txtSearch.Text + "%";

                // Directly incorporate the SearchValue into the query
                string query = "SELECT * FROM CustomerForm_tbl WHERE Name LIKE '" + SearchValue + "' OR CustomerId LIKE '" + SearchValue + "'";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable customerTable = new DataTable();
                    adapter.Fill(customerTable);

                    dataGridView1.DataSource = customerTable;
                }
            }
        }

        private void LoadCustomers()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Query to fetch all customers
                string query = "SELECT * FROM CustomerForm_tbl";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable customerTable = new DataTable();
                    adapter.Fill(customerTable);

                    dataGridView1.DataSource = customerTable; // Set DataSource to the DataGridView

                }
            }
        }
    }
}

