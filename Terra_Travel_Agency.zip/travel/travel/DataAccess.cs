﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;



namespace travel
{

    class DataAccess
    {
        private int selectedStaffId;

        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";

        void connection()
        {
            con = new SqlConnection(connectionString);
            con.Open();
        }




        //// Method to get all customers
        //public DataTable GetAllCustomers()
        //{
        //    DataTable customersTable = new DataTable();

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "SELECT * FROM CustomerForm_tbl";
        //            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
        //            adapter.Fill(customersTable); // Fill the DataTable with customer data
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error loading customer data: " + ex.Message);
        //        }
        //    }

        //    return customersTable;
        //}

        //// Method to add a customer (without using parameters)
        //public void AddCustomer()
        //{
        //    string name = "John Doe"; // Example data, replace with actual values
        //    string email = "john.doe@example.com";
        //    string phone = "1234567890";
        //    string address = "123 Main St";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "INSERT INTO CustomerForm_tbl (Name, Email, Phone, Address) VALUES ('" + name + "', '" + email + "', '" + phone + "', '" + address + "')";
        //            SqlCommand command = new SqlCommand(query, connection);
        //            command.ExecuteNonQuery();
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error adding customer: " + ex.Message);
        //        }
        //    }
        //}

        //// Method to search for customers (without using parameters)
        //public DataTable SearchCustomer()
        //{
        //    DataTable customersTable = new DataTable();
        //    string searchTerm = "John"; // Example data, replace with actual search term

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "SELECT * FROM CustomerForm_tbl WHERE Name LIKE '%" + searchTerm + "%' " +
        //                           "OR Email LIKE '%" + searchTerm + "%' " +
        //                           "OR Phone LIKE '%" + searchTerm + "%'";
        //            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
        //            adapter.Fill(customersTable);
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error searching for customer: " + ex.Message);
        //        }
        //    }

        //    return customersTable;
        //}

        //// Method to add a train
        //public void AddTrain()
        //{
        //    string trainName = "Express Train"; // Example data, replace with actual values
        //    string departure = "Delhi";
        //    string arrival = "Udaipur";
        //    decimal price = 5000;

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "INSERT INTO TrainManagement_info_tbl (TrainName, Departure, Arrival, Price) " +
        //                           "VALUES ('" + trainName + "', '" + departure + "', '" + arrival + "', " + price + ")";
        //            SqlCommand command = new SqlCommand(query, connection);
        //            command.ExecuteNonQuery();
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error adding train: " + ex.Message);
        //        }
        //    }
        //}

        //// Method to search for trains (without using parameters)
        //public DataTable SearchTrain()
        //{
        //    DataTable trainsTable = new DataTable();
        //    string searchTerm = "Express"; // Example data, replace with actual search term

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "SELECT * FROM TrainManagement_info_tbl WHERE TrainName LIKE '%" + searchTerm + "%'";
        //            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
        //            adapter.Fill(trainsTable);
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error searching for train: " + ex.Message);
        //        }
        //    }

        //    return trainsTable;
        //}

        //public void AddHotel()
        //{
        //    string hotelName = "Grand Hotel"; // Example data, replace with actual values
        //    string location = "Udaipur";
        //    decimal pricePerNight = 1500;
        //    int availableRooms = 10;

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "INSERT INTO Hotels_info_tbl (HotelName, Location, PricePerNight, AvailableRooms) " +
        //                           "VALUES ('" + hotelName + "', '" + location + "', " + pricePerNight + ", " + availableRooms + ")";
        //            SqlCommand cmd = new SqlCommand(query, connection);
        //            cmd.ExecuteNonQuery();
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error adding hotel: " + ex.Message);
        //        }
        //    }
        //}

        //public DataTable SearchHotel()
        //{
        //    DataTable hotelsTable = new DataTable();
        //    string searchTerm = "Grand"; // Example data, replace with actual search term

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "SELECT * FROM Hotels_info_tbl WHERE HotelName LIKE '%" + searchTerm + "%' OR Location LIKE '%" + searchTerm + "%'";
        //            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
        //            adapter.Fill(hotelsTable);
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("Error searching for hotel: " + ex.Message);
        //        }
        //    }

        //    return hotelsTable;
        //}


        // Get bookings report
        public DataTable GetBookingsReport()
        {
            DataTable dt = new DataTable();
            string query = "SELECT BookingID, UserID, HotelID, BookingDate, CheckInDate, CheckOutDate, Price, Status FROM Bookings_tbl";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }

            return dt;
        }

        // Get revenue report
        public DataTable GetRevenueReport()
        {
            DataTable dt = new DataTable();
            string query = "SELECT SUM(Price) AS TotalRevenue, COUNT(BookingID) AS BookingCount FROM Bookings_tbl";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }

            return dt;
        }






        /* Add a new staff member to the database
        public void AddStaff()
        {

            string name = "John Doe"; // Replace with actual name
            string position = "Manager"; // Replace with actual position
            string phoneNumber = "1234567890"; // Replace with actual phone number
            string email = "johndoe@example.com"; // Replace with actual email

            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                string query = "INSERT INTO Staff_info_tbl (Name, Position, PhoneNumber, Email) VALUES ('" + name + "', '" + position + "', '" + phoneNumber + "', '" + email + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Method to update staff details
        public void UpdateStaff()
        {
            // Static values, you should replace them with the actual form values
            string name = "John Doe"; // Replace with txtStaffName.Text in actual code
            string position = "Senior Manager"; // Replace with txtPosition.Text
            string phoneNumber = "0987654321"; // Replace with txtPhoneNumber.Text
            string email = "john.doe@newdomain.com"; // Replace with txtEmail.Text

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Staff_info_tbl SET Name = '" + name + "', Position = '" + position +"', PhoneNumber = '" + phoneNumber + "', Email = '" + email +"' WHERE StaffID = " + selectedStaffId;

                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        

        // Method to retrieve all staff members from the database
        public DataTable GetAllStaff()
        {
            DataTable staffTable = new DataTable(); // Create a table to hold staff data
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Staff_info_tbl"; // Select all columns
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(staffTable); // Fill the table with staff data
            }
            return staffTable; // Return the filled table
        }

        */





        //// This method retrieves system logs from the database
        //public DataTable GetSystemLogs()
        //{
        //    DataTable logsTable = new DataTable(); // Create a table to hold log data
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        // Query to select all logs and order them by date
        //        string query = "SELECT * FROM SystemLogs_info_tbl ORDER BY LogDate DESC";
        //        SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
        //        adapter.Fill(logsTable); // Fill the table with log data
        //    }
        //    return logsTable; // Return the filled table
        //}

        // This method runs an SQL command with parameters to insert a new user
        // This method runs an SQL command with parameters to insert a new user
        public void ExecuteQuery()
        {
            string userName = "John Doe"; // Replace with actual name
            string userEmail = "john.doe@example.com"; // Replace with actual email
            string userPhone = "1234567890"; // Replace with actual phone number

            // SQL command to insert a new user
            string query = "INSERT INTO Users (UserName, UserEmail, UserPhone) VALUES ('" + userName + "', '" + userEmail + "', '" + userPhone + "')";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open(); // Open the connection
                command.ExecuteNonQuery(); // Execute the command
            }
        }

        // This method saves a UPI payment to the database
        public void SaveUPIPayment()
        {
            string upiID = "exampleUPI123@bank"; // Replace with actual UPI ID
            DateTime paymentDate = DateTime.Now; // Get the current date and time

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // Open the connection
                string query = "INSERT INTO UPIPayments (UPIID, PaymentDate) VALUES ('" + upiID + "', '" + paymentDate + "')"; // SQL command to insert payment

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery(); // Execute the command to save the payment
                }
            }
        }


        /* Example usage of these methods
        private void ExampleUsage()
        {
            // Get all staff members
            DataTable staffMembers = GetAllStaff();
            // (You can bind staffMembers to a DataGridView or process as needed)

            // Get system logs
            DataTable systemLogs = GetSystemLogs();
            // (You can bind systemLogs to a DataGridView or process as needed)

            // Execute an example query
            AddUser(); // Adding a user with hardcoded values

            // Save a UPI payment
            SaveUPIPayment(); // Adding a UPI payment with hardcoded value
        }
        */


        // Method to cancel the booking in the database
        public string CancelBookingInDatabase()
        {
            string bookingID = "12345"; // Hardcoded Booking ID

            // Check if the booking ID is empty
            if (bookingID == "")
            {
                return "Invalid Booking ID.";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // Open the database connection

                // SQL query to cancel the booking
                string query = "DELETE FROM Bookings WHERE BookingID = '" + bookingID + "'"; // Assuming you have a 'Bookings' table

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Execute the command
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return "Booking cancelled successfully!";
                    }
                    else
                    {
                        return "Booking not found.";
                    }
                }
            }
        }


        //// Method for searching bookings
        //public DataTable SearchBooking(string searchTerm)
        //{
        //    DataTable dataTable = new DataTable();

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open(); // Open the database connection

        //        // SQL query to search for bookings
        //        string query = "SELECT * FROM Bookings WHERE BookingDetails LIKE '%' + BookingDetails + '%'"; // Modify this based on your table structure

        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            // Parameters to the SQL query
        //            command.Parameters.Add(new SqlParameter("BookingDetails", "%" + searchTerm + "%"));

        //            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
        //            {
        //                adapter.Fill(dataTable); // Fill the DataTable with the results
        //            }
        //        }
        //    }

        //    return dataTable; // Return the populated DataTable
        //}


        //public string CancelBooking()
        //{
        //    string bookingID = "12345"; // Replace with the actual booking ID you want to cancel

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            connection.Open();
        //            string query = "DELETE FROM Bookings_tbl WHERE BookingID = BookingID"; // Assuming BookingID is the column name
        //            SqlCommand command = new SqlCommand(query, connection);
        //            command.Parameters.Add(new SqlParameter("BookingID", bookingID)); // No '@' symbol

        //            int rowsAffected = command.ExecuteNonQuery();

        //            if (rowsAffected > 0)
        //            {
        //                return "Booking cancelled successfully.";
        //            }
        //            else
        //            {
        //                return "Booking not found or already cancelled.";
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            return "Error cancelling booking: " + ex.Message;
        //        }
        //    }
        //}


        //public void InsertTrainBooking()
        //{
        //    string trainName = "Express Train"; // Replace with actual train name
        //    string route = "City A to City B"; // Replace with actual route
        //    DateTime travelDate = DateTime.Now; // Replace with actual travel date
        //    int seats = 2; // Replace with the number of seats
        //    decimal price = 500.00m; // Replace with actual price

        //    string query = "INSERT INTO TrainBooking_tbl (TrainName, Route, TravelDate, Seats, Price) " +
        //                   "VALUES ('" + trainName + "', '" + route + "', '" + travelDate + "', " + seats + ", " + price + ")";

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand(query, con);
        //        con.Open();
        //        cmd.ExecuteNonQuery();
        //    }
        //}

        //public void CompleteTrainCheckout()
        //{
        //    string trainName = "Express Train"; // Replace with actual train name
        //    string route = "City A to City B"; // Replace with actual route
        //    DateTime travelDate = DateTime.Now; // Replace with actual travel date
        //    int seats = 2; // Replace with the number of seats
        //    decimal totalAmount = 1000.00m; // Replace with actual total amount

        //    string query = "INSERT INTO TrainBooking_tbl (TrainName, Route, TravelDate, Seats, TotalAmount) " +
        //                   "VALUES ('" + trainName + "', '" + route + "', '" + travelDate + "', " + seats + ", " + totalAmount + ")";

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand(query, con);
        //        con.Open();
        //        cmd.ExecuteNonQuery();
        //    }
        //}


        public void AddUser()
        {
            string username = "johndoe"; // Replace with actual username
            string password = "securepassword"; // Replace with actual password
            string role = "Admin"; // Replace with actual role
            string email = "johndoe@example.com"; // Replace with actual email

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Users_info_tbl (Username, Password, Role, Email) VALUES ('" + username + "', '" + password + "', '" + role + "', '" + email + "')";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        /*   public void AddUser()
        {
            string userName = "John Doe"; // Hardcoded name
            string userEmail = "john@example.com"; // Hardcoded email
            string userPhone = "123-456-7890"; // Hardcoded phone number

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Users (UserName, UserEmail, UserPhone) VALUES ('" + userName + "', '" + userEmail + "', '" + userPhone + "')";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open(); // Open the connection
                command.ExecuteNonQuery(); // Execute the command
            }
        }  */

        public void UpdateUser()
        {
            int userID = 1; // Replace with actual user ID
            string username = "johndoe"; // Replace with actual username
            string password = "newpassword"; // Replace with actual password
            string role = "User"; // Replace with actual role
            string email = "johndoe@example.com"; // Replace with actual email

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Users_info_tbl SET Username = '" + username + "', Password = '" + password + "', Role = '" + role + "', Email = '" + email + "' WHERE UserID = " + userID;

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }


        public void DeleteUser()
        {
            int userID = 1; // Replace with actual user ID

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "DELETE FROM Users_info_tbl WHERE UserID = " + userID; // Use direct concatenation for user ID

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public DataTable GetAllUsers()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM UserAccounts_info_tbl"; // Use direct query
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable usersTable = new DataTable();
                adapter.Fill(usersTable);
                return usersTable;
            }
        }

        // Method to get train schedules for a selected route and date
        public DataTable GetTrainSchedule()
        {
            string route = "Delhi to Udaipur"; // Replace with actual route
            DateTime travelDate = DateTime.Now; // Replace with actual travel date

            string query = "SELECT TrainName, DepartureTime, ArrivalTime, AvailableSeats " +
                           "FROM TrainSchedule_tbl " +
                           "WHERE Route = '" + route + "' AND CAST(DepartureTime AS DATE) = '" + travelDate.ToString("yyyy-MM-dd") + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable trainScheduleTable = new DataTable();

                    try
                    {
                        connection.Open();
                        adapter.Fill(trainScheduleTable); // Fill the DataTable with train schedule data
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Error fetching train schedule: " + ex.Message);
                    }

                    return trainScheduleTable;
                }
            }
        }

        //// Method to get hotel availability for a given location
        //public DataTable GetHotelAvailability()
        //{
        //    string location = "Udaipur"; // Replace with actual location

        //    string query = "SELECT HotelName, Location, PricePerNight, AvailableRooms " +
        //                   "FROM Hotels_info_tbl " +
        //                   "WHERE Location = '" + location + "'";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            SqlDataAdapter adapter = new SqlDataAdapter(command);
        //            DataTable hotelScheduleTable = new DataTable();

        //            try
        //            {
        //                connection.Open();
        //                adapter.Fill(hotelScheduleTable); // Fill the DataTable with hotel availability data
        //            }
        //            catch (Exception ex)
        //            {
        //                throw new Exception("Error fetching hotel availability: " + ex.Message);
        //            }

        //            return hotelScheduleTable;
        //        }
        //    }
        //}


        public void SignupUser()
        {
            string username = "testUser"; // Replace with actual username
            string password = "testPassword"; // Replace with actual password
            string role = "User"; // Replace with actual role
            string email = "testuser@example.com"; // Replace with actual email
            string phone = "1234567890"; // Replace with actual phone number

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Users_tbl (Username, Password, Role, Email, Phone) VALUES ('" + username + "', '" + password + "', '" + role + "', '" + email + "', '" + phone + "')";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

    }
}