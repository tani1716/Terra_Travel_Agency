﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace travel
{
    public partial class HotelBookingForm : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";

        public HotelBookingForm()
        {
            InitializeComponent();
            LoadHotelNames(); // Load hotel names when the form loads
            GenerateBookingID(); // Generate a new Booking ID
            comboBoxNumberOfRooms.SelectedIndexChanged += new EventHandler(AviliableRooms_SelectedIndexChanged); // Event for room selection
            this.Load += new EventHandler(HotelBookingForm_Load); // Ensure the Load event is wired up

        }


        // Method to get hotel availability from the database without using arguments
        private DataTable GetHotelAvailability()
        {
            string location = "Udaipur"; // Replace with the actual location as needed
            string query = "SELECT HotelName, Location, PricePerNight, AvailableRooms FROM Hotels_info_tbl WHERE Location = '" + location + "'";
            DataTable hotelScheduleTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    connection.Open();
                    adapter.Fill(hotelScheduleTable); // Fill the DataTable with hotel availability data
                }
            }

            return hotelScheduleTable;
        }


        private void CalculateTotalAmount()
        {
            decimal pricePerNight;
            if (decimal.TryParse(textBoxPricePerNight.Text, out pricePerNight))
            {
                // Get the selected number of rooms from the ComboBox
                int numberOfRooms = int.Parse(comboBoxNumberOfRooms.SelectedItem.ToString());
                decimal totalAmount = pricePerNight * numberOfRooms; // Calculate total amount
                textBoxTotalAmount.Text = totalAmount.ToString("F2"); // Format to two decimal places
            }
        }

        // Method to generate a new booking ID
        private void GenerateBookingID()
        {
            string query = "SELECT MAX(BookingID) FROM HotelBookings_tbl"; // Assuming 'HotelBookings_tbl' is your table for bookings

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    object result = command.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        int lastBookingID = Convert.ToInt32(result);
                        textBoxBookingID.Text = (lastBookingID + 1).ToString(); // Increment and set the BookingID
                    }
                    else
                    {
                        textBoxBookingID.Text = "1"; // First booking
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error generating BookingID: " + ex.Message);
                }
            }
        }

        // Method to load hotel names into the ComboBox
        private void LoadHotelNames()
        {
            string query = "SELECT BookingID, CustomerID, HotelName, CheckInDate, CheckOutDate, NumberOfRooms, TotalAmount FROM HotelBookings_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable bookingsTable = new DataTable();
                try
                {
                    connection.Open();
                    adapter.Fill(bookingsTable); // Fill the DataTable with booking data
                    dataGridViewBookings.DataSource = bookingsTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading booking data: " + ex.Message);
                }
            }
        }

        private void ConfirmBooking()
        {
            if (CheckHotelAvailability())
            {
                string bookingID = textBoxBookingID.Text;
                string customerID = textBoxCustomerID.Text;
                string hotelName = comboBoxHotelName.Text;
                DateTime checkInDate = dateTimePickerCheckInDate.Value;
                DateTime checkOutDate = dateTimePickerCheckOutDate.Value;
                int numberOfRooms = (int)comboBoxNumberOfRooms.SelectedItem; // Get selected number of rooms
                decimal pricePerNight = decimal.Parse(textBoxPricePerNight.Text);
                decimal totalAmount = numberOfRooms * pricePerNight; // Calculate total amount

                string query = "INSERT INTO HotelBookings_tbl (BookingID, CustomerID, HotelName, CheckInDate, CheckOutDate, NumberOfRooms, TotalAmount) " +
                               "VALUES (" + bookingID + ", '" + customerID + "', '" + hotelName + "', '" + checkInDate.ToString("yyyy-MM-dd") + "', '" + checkOutDate.ToString("yyyy-MM-dd") + "', " + numberOfRooms + ", " + totalAmount + ")";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Booking confirmed successfully!");
                        LoadBookingsData(); // Load updated booking data into DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error confirming booking: " + ex.Message);
                    }
                }
            }

        }

        private void HotelBookingForm_Load(object sender, EventArgs e)
        {
            LoadBookingsData(); // Load booking data when the form loads

        }

        private void btnBookHotel_Click(object sender, EventArgs e)
        {
            ConfirmBooking(); // Call confirm booking on button click

        }

        private void comboBoxHotelName_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedHotel = comboBoxHotelName.Text;
            string query = "SELECT PricePerNight, AvailableRooms FROM Hotels_info_tbl WHERE HotelName = '" + selectedHotel + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        textBoxPricePerNight.Text = reader["PricePerNight"].ToString();
                        int availableRooms = (int)reader["AvailableRooms"];

                        // Load available rooms into the ComboBox
                        comboBoxNumberOfRooms.Items.Clear();
                        for (int i = 1; i <= availableRooms; i++)
                        {
                            comboBoxNumberOfRooms.Items.Add(i);
                        }
                        if (comboBoxNumberOfRooms.Items.Count > 0)
                        {
                            comboBoxNumberOfRooms.SelectedIndex = 0; // Select the first available option
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching hotel price: " + ex.Message);
                }
            }
        }


        // Method to check hotel availability
        private bool CheckHotelAvailability()
        {
            string hotelName = comboBoxHotelName.Text;
            DateTime checkInDate = dateTimePickerCheckInDate.Value;
            DateTime checkOutDate = dateTimePickerCheckOutDate.Value;

            string query = "SELECT AvailableRooms FROM Hotels_info_tbl WHERE HotelName = '" + hotelName + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    int availableRooms = (int)command.ExecuteScalar();

                    // Ensure at least one room is available for the selected dates
                    if (availableRooms > 0)
                    {
                        return true; // Room is available
                    }
                    else
                    {
                        MessageBox.Show("No rooms available for the selected dates.");
                        return false; // No availability
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error checking availability: " + ex.Message);
                    return false;
                }
            }
        }




        private void AviliableRooms_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculateTotalAmount(); // Recalculate total amount when room selection changes

        }

        private void LoadBookingsData()
        {
            string query = "SELECT BookingID, CustomerID, HotelName, CheckInDate, CheckOutDate, NumberOfRooms, TotalAmount FROM HotelBookings_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable bookingsTable = new DataTable();
                try
                {
                    connection.Open();
                    adapter.Fill(bookingsTable); // Fill the DataTable with booking data
                    dataGridViewBookings.DataSource = bookingsTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading booking data: " + ex.Message);
                }
            }
        }



    }
}