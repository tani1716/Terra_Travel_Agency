﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class ScheduleForm : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";

        DataAccess dataAccess = new DataAccess(); // Ensure this is correct

        public ScheduleForm()
        {
            InitializeComponent();
        }

        private void ScheduleForm_Load(object sender, EventArgs e)
        {
            LoadRoutes();

        }

        private void LoadRoutes()
        {
            // Load available routes into the ComboBox (assuming routes are distinct)
            string query = "SELECT DISTINCT Route FROM TrainSchedule_tbl";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbRoute.Items.Add(reader["Route"].ToString());
                    }
                }
            }
        }

        private void btnCheckSchedule_Click(object sender, EventArgs e)
        {
            // Fetch both train and hotel schedules based on selected route and date
            string route = cmbRoute.SelectedItem.ToString();
            DateTime travelDate = dtpTravelDate.Value.Date;

            // Load Train Schedule
            LoadTrainSchedule(route, travelDate);

            // Load Hotel Schedule (availability at the destination)
        //    LoadHotelSchedule(route);
        }


        private void LoadTrainSchedule(string route, DateTime travelDate)
        {
            // Query to get train schedules
            string trainQuery = "SELECT TrainName, DepartureTime, ArrivalTime, AvailableSeats FROM TrainSchedule_tbl WHERE Route = @Route AND CAST(DepartureTime AS DATE) = @TravelDate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(trainQuery, connection))
                {
                    command.Parameters.AddWithValue("Route", route);
                    command.Parameters.AddWithValue("TravelDate", travelDate);

                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable trainScheduleTable = new DataTable();
                    adapter.Fill(trainScheduleTable);

                    // Bind train schedule data to the DataGridView for train schedule
                    dgvTrainSchedule.DataSource = trainScheduleTable;
                }
            }
        }

    /*    private void LoadHotelSchedule(string route)
        {
            // Query to get hotel availability based on destination
            string hotelQuery = "SELECT HotelName, Location, PricePerNight, AvailableRooms FROM Hotels_info_tbl WHERE Location = @Route";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(hotelQuery, connection))
                {
                    command.Parameters.AddWithValue("Route", route);

                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable hotelScheduleTable = new DataTable();
                    adapter.Fill(hotelScheduleTable);

                    // Bind hotel availability data to the DataGridView for hotel schedule
                    dgvHotelSchedule.DataSource = hotelScheduleTable;
                }
            }
        }*/
    }
}