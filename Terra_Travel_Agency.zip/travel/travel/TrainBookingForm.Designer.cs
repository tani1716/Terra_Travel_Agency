﻿
namespace travel
{
    partial class TrainBookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewBookings = new System.Windows.Forms.DataGridView();
            this.labelTrainName = new System.Windows.Forms.Label();
            this.labelArrival = new System.Windows.Forms.Label();
            this.labelDeparture = new System.Windows.Forms.Label();
            this.labelSeats = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnBookTrain = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.payment = new System.Windows.Forms.Label();
            this.hotel = new System.Windows.Forms.Label();
            this.train = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.trainbook = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelTotalAmount = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBoxTrainName = new System.Windows.Forms.ComboBox();
            this.comboBoxRouteFrom = new System.Windows.Forms.ComboBox();
            this.comboBoxRouteTo = new System.Windows.Forms.ComboBox();
            this.textBoxTotalAmount = new System.Windows.Forms.TextBox();
            this.comboBoxArrival = new System.Windows.Forms.ComboBox();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.comboBoxDeparture = new System.Windows.Forms.ComboBox();
            this.textBoxNumberOfSeats = new System.Windows.Forms.ComboBox();
            this.textBoxCustomerName = new System.Windows.Forms.TextBox();
            this.textBoxPricePerSeat = new System.Windows.Forms.TextBox();
            this.dateTimePickerDeparture = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerArrival = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewBookings
            // 
            this.dataGridViewBookings.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBookings.Location = new System.Drawing.Point(745, 192);
            this.dataGridViewBookings.Name = "dataGridViewBookings";
            this.dataGridViewBookings.RowHeadersWidth = 51;
            this.dataGridViewBookings.RowTemplate.Height = 24;
            this.dataGridViewBookings.Size = new System.Drawing.Size(363, 356);
            this.dataGridViewBookings.TabIndex = 4;
            // 
            // labelTrainName
            // 
            this.labelTrainName.AutoSize = true;
            this.labelTrainName.Location = new System.Drawing.Point(325, 244);
            this.labelTrainName.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelTrainName.Name = "labelTrainName";
            this.labelTrainName.Size = new System.Drawing.Size(82, 17);
            this.labelTrainName.TabIndex = 6;
            this.labelTrainName.Text = "Train Name\t";
            // 
            // labelArrival
            // 
            this.labelArrival.AutoSize = true;
            this.labelArrival.Location = new System.Drawing.Point(324, 309);
            this.labelArrival.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelArrival.Name = "labelArrival";
            this.labelArrival.Size = new System.Drawing.Size(83, 17);
            this.labelArrival.TabIndex = 7;
            this.labelArrival.Text = "Arrival Time";
            // 
            // labelDeparture
            // 
            this.labelDeparture.AutoSize = true;
            this.labelDeparture.Location = new System.Drawing.Point(324, 363);
            this.labelDeparture.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelDeparture.Name = "labelDeparture";
            this.labelDeparture.Size = new System.Drawing.Size(107, 17);
            this.labelDeparture.TabIndex = 8;
            this.labelDeparture.Text = "Departure Time";
            // 
            // labelSeats
            // 
            this.labelSeats.AutoSize = true;
            this.labelSeats.Location = new System.Drawing.Point(317, 419);
            this.labelSeats.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelSeats.Name = "labelSeats";
            this.labelSeats.Size = new System.Drawing.Size(114, 17);
            this.labelSeats.TabIndex = 9;
            this.labelSeats.Text = "Number of Seats";
            // 
            // btnBookTrain
            // 
            this.btnBookTrain.BackColor = System.Drawing.Color.Tomato;
            this.btnBookTrain.Location = new System.Drawing.Point(822, 585);
            this.btnBookTrain.Name = "btnBookTrain";
            this.btnBookTrain.Size = new System.Drawing.Size(96, 60);
            this.btnBookTrain.TabIndex = 16;
            this.btnBookTrain.Text = "ok";
            this.btnBookTrain.UseVisualStyleBackColor = false;
            this.btnBookTrain.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(98, 615);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 17);
            this.label6.TabIndex = 82;
            this.label6.Text = "logout";
            // 
            // payment
            // 
            this.payment.AutoSize = true;
            this.payment.Location = new System.Drawing.Point(95, 514);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(74, 17);
            this.payment.TabIndex = 81;
            this.payment.Text = "PAYMENT";
            // 
            // hotel
            // 
            this.hotel.AutoSize = true;
            this.hotel.Location = new System.Drawing.Point(95, 419);
            this.hotel.Name = "hotel";
            this.hotel.Size = new System.Drawing.Size(123, 17);
            this.hotel.TabIndex = 80;
            this.hotel.Text = "HOTEL BOOKING";
            // 
            // train
            // 
            this.train.AutoSize = true;
            this.train.Location = new System.Drawing.Point(94, 326);
            this.train.Name = "train";
            this.train.Size = new System.Drawing.Size(117, 17);
            this.train.TabIndex = 79;
            this.train.Text = "TRAIN BOOKING";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(95, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 17);
            this.label7.TabIndex = 78;
            this.label7.Text = "Login";
            // 
            // trainbook
            // 
            this.trainbook.AutoSize = true;
            this.trainbook.BackColor = System.Drawing.Color.PeachPuff;
            this.trainbook.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainbook.ForeColor = System.Drawing.Color.LightCoral;
            this.trainbook.Location = new System.Drawing.Point(371, 55);
            this.trainbook.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.trainbook.Name = "trainbook";
            this.trainbook.Size = new System.Drawing.Size(507, 69);
            this.trainbook.TabIndex = 83;
            this.trainbook.Text = "TRAIN BOOKING";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::travel.Properties.Resources.l1;
            this.pictureBox6.Location = new System.Drawing.Point(18, 599);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 77;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::travel.Properties.Resources.pay;
            this.pictureBox5.Location = new System.Drawing.Point(17, 494);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 76;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::travel.Properties.Resources.hotel;
            this.pictureBox4.Location = new System.Drawing.Point(17, 397);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 75;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::travel.Properties.Resources.trainmanage;
            this.pictureBox3.Location = new System.Drawing.Point(17, 304);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 74;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::travel.Properties.Resources.login1;
            this.pictureBox2.Location = new System.Drawing.Point(18, 202);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 73;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::travel.Properties.Resources.Travel_agency__1__removebg_preview__2_;
            this.pictureBox1.Location = new System.Drawing.Point(18, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(159, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 72;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::travel.Properties.Resources.back;
            this.pictureBox9.Location = new System.Drawing.Point(1078, 585);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(71, 60);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 84;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(317, 477);
            this.labelPrice.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(99, 17);
            this.labelPrice.TabIndex = 85;
            this.labelPrice.Text = "Price Per Seat";
            // 
            // labelTotalAmount
            // 
            this.labelTotalAmount.AutoSize = true;
            this.labelTotalAmount.Location = new System.Drawing.Point(324, 531);
            this.labelTotalAmount.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelTotalAmount.Name = "labelTotalAmount";
            this.labelTotalAmount.Size = new System.Drawing.Size(92, 17);
            this.labelTotalAmount.TabIndex = 87;
            this.labelTotalAmount.Text = "Total Amount";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(300, 175);
            this.label10.MaximumSize = new System.Drawing.Size(500, 500);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 17);
            this.label10.TabIndex = 90;
            this.label10.Text = "FROM";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(502, 175);
            this.label11.MaximumSize = new System.Drawing.Size(500, 500);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 17);
            this.label11.TabIndex = 91;
            this.label11.Text = "TO";
            // 
            // comboBoxTrainName
            // 
            this.comboBoxTrainName.FormattingEnabled = true;
            this.comboBoxTrainName.Location = new System.Drawing.Point(432, 244);
            this.comboBoxTrainName.Name = "comboBoxTrainName";
            this.comboBoxTrainName.Size = new System.Drawing.Size(92, 24);
            this.comboBoxTrainName.TabIndex = 96;
            // 
            // comboBoxRouteFrom
            // 
            this.comboBoxRouteFrom.FormattingEnabled = true;
            this.comboBoxRouteFrom.Location = new System.Drawing.Point(386, 172);
            this.comboBoxRouteFrom.Name = "comboBoxRouteFrom";
            this.comboBoxRouteFrom.Size = new System.Drawing.Size(58, 24);
            this.comboBoxRouteFrom.TabIndex = 98;
            // 
            // comboBoxRouteTo
            // 
            this.comboBoxRouteTo.FormattingEnabled = true;
            this.comboBoxRouteTo.Location = new System.Drawing.Point(569, 172);
            this.comboBoxRouteTo.Name = "comboBoxRouteTo";
            this.comboBoxRouteTo.Size = new System.Drawing.Size(52, 24);
            this.comboBoxRouteTo.TabIndex = 99;
            // 
            // textBoxTotalAmount
            // 
            this.textBoxTotalAmount.Location = new System.Drawing.Point(457, 531);
            this.textBoxTotalAmount.Name = "textBoxTotalAmount";
            this.textBoxTotalAmount.Size = new System.Drawing.Size(89, 22);
            this.textBoxTotalAmount.TabIndex = 101;
            // 
            // comboBoxArrival
            // 
            this.comboBoxArrival.FormattingEnabled = true;
            this.comboBoxArrival.Location = new System.Drawing.Point(432, 309);
            this.comboBoxArrival.Name = "comboBoxArrival";
            this.comboBoxArrival.Size = new System.Drawing.Size(101, 24);
            this.comboBoxArrival.TabIndex = 104;
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.Location = new System.Drawing.Point(317, 585);
            this.labelCustomerName.MaximumSize = new System.Drawing.Size(500, 500);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(109, 17);
            this.labelCustomerName.TabIndex = 107;
            this.labelCustomerName.Text = "Customer Name";
            // 
            // comboBoxDeparture
            // 
            this.comboBoxDeparture.FormattingEnabled = true;
            this.comboBoxDeparture.Location = new System.Drawing.Point(457, 363);
            this.comboBoxDeparture.Name = "comboBoxDeparture";
            this.comboBoxDeparture.Size = new System.Drawing.Size(89, 24);
            this.comboBoxDeparture.TabIndex = 108;
            // 
            // textBoxNumberOfSeats
            // 
            this.textBoxNumberOfSeats.FormattingEnabled = true;
            this.textBoxNumberOfSeats.Location = new System.Drawing.Point(457, 423);
            this.textBoxNumberOfSeats.Name = "textBoxNumberOfSeats";
            this.textBoxNumberOfSeats.Size = new System.Drawing.Size(89, 24);
            this.textBoxNumberOfSeats.TabIndex = 109;
            this.textBoxNumberOfSeats.TextChanged += new System.EventHandler(this.textBoxNumberOfSeats_TextChanged);
            // 
            // textBoxCustomerName
            // 
            this.textBoxCustomerName.Location = new System.Drawing.Point(457, 585);
            this.textBoxCustomerName.Name = "textBoxCustomerName";
            this.textBoxCustomerName.Size = new System.Drawing.Size(89, 22);
            this.textBoxCustomerName.TabIndex = 112;
            // 
            // textBoxPricePerSeat
            // 
            this.textBoxPricePerSeat.Location = new System.Drawing.Point(457, 472);
            this.textBoxPricePerSeat.Name = "textBoxPricePerSeat";
            this.textBoxPricePerSeat.Size = new System.Drawing.Size(100, 22);
            this.textBoxPricePerSeat.TabIndex = 113;
            // 
            // dateTimePickerDeparture
            // 
            this.dateTimePickerDeparture.Location = new System.Drawing.Point(569, 364);
            this.dateTimePickerDeparture.Name = "dateTimePickerDeparture";
            this.dateTimePickerDeparture.Size = new System.Drawing.Size(122, 22);
            this.dateTimePickerDeparture.TabIndex = 114;
            // 
            // dateTimePickerArrival
            // 
            this.dateTimePickerArrival.Location = new System.Drawing.Point(569, 309);
            this.dateTimePickerArrival.Name = "dateTimePickerArrival";
            this.dateTimePickerArrival.Size = new System.Drawing.Size(122, 22);
            this.dateTimePickerArrival.TabIndex = 115;
            // 
            // TrainBookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.dateTimePickerArrival);
            this.Controls.Add(this.dateTimePickerDeparture);
            this.Controls.Add(this.textBoxPricePerSeat);
            this.Controls.Add(this.textBoxCustomerName);
            this.Controls.Add(this.textBoxNumberOfSeats);
            this.Controls.Add(this.comboBoxDeparture);
            this.Controls.Add(this.labelCustomerName);
            this.Controls.Add(this.comboBoxArrival);
            this.Controls.Add(this.textBoxTotalAmount);
            this.Controls.Add(this.comboBoxRouteTo);
            this.Controls.Add(this.comboBoxRouteFrom);
            this.Controls.Add(this.comboBoxTrainName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelTotalAmount);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.trainbook);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.hotel);
            this.Controls.Add(this.train);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnBookTrain);
            this.Controls.Add(this.labelSeats);
            this.Controls.Add(this.labelDeparture);
            this.Controls.Add(this.labelArrival);
            this.Controls.Add(this.labelTrainName);
            this.Controls.Add(this.dataGridViewBookings);
            this.Name = "TrainBookingForm";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Text = "TrainBookingForm";
            this.Load += new System.EventHandler(this.TrainBookingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewBookings;
        private System.Windows.Forms.Label labelTrainName;
        private System.Windows.Forms.Label labelArrival;
        private System.Windows.Forms.Label labelDeparture;
        private System.Windows.Forms.Label labelSeats;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnBookTrain;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label payment;
        private System.Windows.Forms.Label hotel;
        private System.Windows.Forms.Label train;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label trainbook;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelTotalAmount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxTrainName;
        private System.Windows.Forms.ComboBox comboBoxRouteFrom;
        private System.Windows.Forms.ComboBox comboBoxRouteTo;
        private System.Windows.Forms.TextBox textBoxTotalAmount;
        private System.Windows.Forms.ComboBox comboBoxArrival;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.ComboBox comboBoxDeparture;
        private System.Windows.Forms.ComboBox textBoxNumberOfSeats;
        private System.Windows.Forms.TextBox textBoxCustomerName;
        private System.Windows.Forms.TextBox textBoxPricePerSeat;
        private System.Windows.Forms.DateTimePicker dateTimePickerDeparture;
        private System.Windows.Forms.DateTimePicker dateTimePickerArrival;
    }
}