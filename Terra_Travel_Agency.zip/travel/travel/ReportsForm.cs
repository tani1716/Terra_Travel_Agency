﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace travel
{
    public partial class ReportsForm : Form
    {
        DataAccess dataAccess = new DataAccess();

        public ReportsForm()
        {
            InitializeComponent();
        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {


            // Set the default selected item
            cmbReportType.SelectedIndex = 0; // Optional: select the first item by default



        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            // Get the selected report type from the ComboBox
            string selectedReport = cmbReportType.SelectedItem.ToString();

            // Clear existing columns
            dataGridViewReports.Columns.Clear();

            if (selectedReport == "Bookings Report")
            {
                // Call method to get bookings report data
                DataTable bookingsReport = dataAccess.GetBookingsReport();

                // Define columns for bookings report
                dataGridViewReports.Columns.Add("BookingID", "Booking ID");
                dataGridViewReports.Columns.Add("UserID", "User ID");
                dataGridViewReports.Columns.Add("HotelID", "Hotel ID");
                dataGridViewReports.Columns.Add("BookingDate", "Booking Date");
                dataGridViewReports.Columns.Add("CheckInDate", "Check-in Date");
                dataGridViewReports.Columns.Add("CheckOutDate", "Check-out Date");
                dataGridViewReports.Columns.Add("Price", "Price");
                dataGridViewReports.Columns.Add("Status", "Status");

                // Bind data to DataGridView
                dataGridViewReports.DataSource = bookingsReport;
            }
            else if (selectedReport == "Revenue Report")
            {
                // Call method to get revenue report data
                DataTable revenueReport = dataAccess.GetRevenueReport();

                // Define columns for revenue report
                dataGridViewReports.Columns.Add("TotalRevenue", "Total Revenue");
                dataGridViewReports.Columns.Add("BookingCount", "Booking Count");
                dataGridViewReports.Columns.Add("DateRange", "Date Range"); // Optional

                // Bind data to DataGridView
                dataGridViewReports.DataSource = revenueReport;
            }

            MessageBox.Show("Report generated successfully!");
        }
    }
    }