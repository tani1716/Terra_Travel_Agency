﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class HotelManagementForm : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";


        public HotelManagementForm()
        {
            InitializeComponent();
            dataGridViewHotels.SelectionChanged += dataGridViewHotels_SelectionChanged;
            AddTruncateButtonColumn(); // Add the Truncate button column
            dataGridViewHotels.SelectionChanged += dataGridViewHotels_SelectionChanged;
            dataGridViewHotels.CellClick += dataGridViewHotels_CellClick; // Handle cell click events

        }

        private void AddHotel()
        {
            try
            {
                string hotelName = textBoxHotelName.Text;
                string location = textBoxLocation.Text;
                decimal pricePerNight;
                int availableRooms;

                // Validate and parse inputs
                if (decimal.TryParse(textBoxPricePerNight.Text, out pricePerNight) &&
                    int.TryParse(textBoxAvailableRooms.Text, out availableRooms))
                {
                    string query = "INSERT INTO Hotels_info_tbl (HotelName, Location, PricePerNight, AvailableRooms) " +
                                   "VALUES ('" + hotelName + "', '" + location + "', " + pricePerNight + ", " + availableRooms + ")";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            connection.Open();
                            int result = command.ExecuteNonQuery();

                            if (result > 0)
                            {
                                MessageBox.Show("Hotel added successfully!");
                                LoadHotelsData(); // Refresh DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Failed to add hotel. Please try again.");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter valid numeric values for Price Per Night and Available Rooms.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding hotel: " + ex.Message);
            }
        }




        private void SearchHotel()
        {
            string searchText = textBoxSearchHotel.Text;

            string query = "SELECT HotelID, HotelName, Location, PricePerNight, AvailableRooms FROM Hotels_info_tbl " +
                           "WHERE HotelName LIKE '%" + searchText + "%' OR Location LIKE '%" + searchText + "%'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                try
                {
                    connection.Open();
                    adapter.Fill(dataTable);

                    dataGridViewHotels.AutoGenerateColumns = true;
                    dataGridViewHotels.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error searching for hotels: " + ex.Message);
                }
            }
        }

        private void UpdateHotel()
        {
            try
            {
                if (textBoxHotelID.Text.Trim() != "")
                {
                    int hotelID = int.Parse(textBoxHotelID.Text);
                    string hotelName = textBoxHotelName.Text;
                    string location = textBoxLocation.Text;
                    string pricePerNight = textBoxPricePerNight.Text;
                    int availableRooms;

                    // Validate numeric input for available rooms
                    if (!int.TryParse(textBoxAvailableRooms.Text.Trim(), out availableRooms))
                    {
                        MessageBox.Show("Please enter a valid numeric value for Available Rooms.");
                        return; // Exit if validation fails
                    }

                    // SQL query for updating the hotel
                    string query = "UPDATE Hotels_info_tbl SET HotelName = '" + hotelName +
                                   "', Location = '" + location +
                                   "', PricePerNight = '" + pricePerNight +
                                   "', AvailableRooms = " + availableRooms +
                                   " WHERE HotelID = " + hotelID;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            connection.Open();
                            int result = command.ExecuteNonQuery();

                            if (result > 0)
                            {
                                MessageBox.Show("Hotel updated successfully!");
                                LoadHotelsData(); // Refresh DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Hotel not found or update failed.");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a hotel to update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating hotel: " + ex.Message);
            }
        }



        private void DeleteHotel()
        {
            try
            {
                if (textBoxHotelID.Text.Trim() != "")
                {
                    int hotelID = int.Parse(textBoxHotelID.Text);

                    // SQL query for deleting the hotel
                    string query = "DELETE FROM Hotels_info_tbl WHERE HotelID = " + hotelID;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            connection.Open();
                            int result = command.ExecuteNonQuery();

                            if (result > 0)
                            {
                                MessageBox.Show("Hotel deleted successfully!");
                                LoadHotelsData(); // Refresh DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Hotel not found or deletion failed.");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a hotel to delete.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting hotel: " + ex.Message);
            }
        }



        private void TruncateHotelsTable()
        {
            try
            {
                string query = "TRUNCATE TABLE Hotels_info_tbl";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("All records have been deleted successfully!");
                        LoadHotelsData(); // Refresh the DataGridView after truncating the table
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error truncating the table: " + ex.Message);
            }
        }




        private void LoadHotelsData()
        {
            string query = "SELECT HotelID, HotelName, Location, PricePerNight, AvailableRooms FROM Hotels_info_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                try
                {
                    connection.Open();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to the DataGridView
                    dataGridViewHotels.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading hotel data: " + ex.Message);
                }
            }
        }



        private void HotelManagementForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAddHotel_Click(object sender, EventArgs e)
        {
            AddHotel(); // Call the method to add the hotel

        }

        private void btnSearchHotel_Click(object sender, EventArgs e)
        {
            SearchHotel(); // Call the method to search hotels

        }

        private void btnreport_Click(object sender, EventArgs e)
        {
            ReportsForm reportsForm = new ReportsForm();
            reportsForm.Show(); // Use Show() to open non-modal, or ShowDialog() for modal
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateHotel();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DeleteHotel(); // Call the method to delete the hotel

        }

        private void dataGridViewHotels_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewHotels.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewHotels.SelectedRows[0];

                // Extract values from the selected row and populate the text boxes
                textBoxHotelID.Text = selectedRow.Cells["HotelID"].Value.ToString();
                textBoxHotelName.Text = selectedRow.Cells["HotelName"].Value.ToString();
                textBoxLocation.Text = selectedRow.Cells["Location"].Value.ToString();
                textBoxPricePerNight.Text = selectedRow.Cells["PricePerNight"].Value.ToString();
                textBoxAvailableRooms.Text = selectedRow.Cells["AvailableRooms"].Value.ToString();
            }
        }

        private void AddTruncateButtonColumn()
        {
            // Check if the button column already exists
            if (!dataGridViewHotels.Columns.Contains("TruncateColumn"))
            {
                DataGridViewButtonColumn truncateButtonColumn = new DataGridViewButtonColumn();
                truncateButtonColumn.Name = "TruncateColumn";
                truncateButtonColumn.HeaderText = "Truncate Table";
                truncateButtonColumn.Text = "Truncate";
                truncateButtonColumn.UseColumnTextForButtonValue = true;

                dataGridViewHotels.Columns.Add(truncateButtonColumn);
            }
        }

   
            private void dataGridViewHotels_CellClick(object sender, DataGridViewCellEventArgs e)
            {
                // Ensure the clicked column and row are valid
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && e.ColumnIndex < dataGridViewHotels.Columns.Count)
                {
                    // Check if the clicked cell is part of the Truncate button column
                    if (dataGridViewHotels.Columns[e.ColumnIndex].Name == "TruncateColumn")
                    {
                        DialogResult result = MessageBox.Show("Are you sure you want to delete all records?", "Confirm Truncate", MessageBoxButtons.YesNo);

                        if (result == DialogResult.Yes)
                        {
                            TruncateHotelsTable();
                        }
                    }
                }
            }

        
    }
}
