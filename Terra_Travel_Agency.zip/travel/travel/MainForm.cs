﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace travel
{
    public partial class MainForm : Form
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";

        private string loggedInUser;
        private string userRole;


        public MainForm(string username, string role)
        {
            InitializeComponent();
            loggedInUser = username;
            userRole = role;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ShowLoggedInUserData();

        }

        private void ShowLoggedInUserData()
        {
          /*  DataTable dt = new DataTable();
            dt.Columns.Add("username");
            dt.Columns.Add("role");
            dt.Rows.Add(loggedInUser, userRole);
            dataGridView1.DataSource = dt;*/
        }
        private void btnCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                CustomerForm customerForm = new CustomerForm();
                customerForm.Show(); // or ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

           new CustomerForm().Show();

        }

        private void btnBookings_Click(object sender, EventArgs e)
        {
            new BookingForm().Show();
        }

        private void btnManageTrains_Click(object sender, EventArgs e)
        {
           new TrainBookingForm().Show();
        }

        private void btnManageHotels_Click(object sender, EventArgs e)
        {
            new HotelBookingForm().Show();
        }

        private void btnReports_Click(object sender, EventArgs e) //checkout
        {
            new CheckOutForm().Show();
        }

        private void btnPayment_Click(object sender, EventArgs e) //feedback
        {
            new FeedbackForm().Show();
        }

        private void btnLoyaltyProgram_Click(object sender, EventArgs e) //payment
        {
            new PaymentForm().Show();
        }

        private void btnSystemLogs_Click(object sender, EventArgs e) //user account
        {
            new UserAccountForm().Show();

        }

        private void CheckDatabaseConnection()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MessageBox.Show("Connection Successful");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection Failed: " + ex.Message);
                }
            }
        }



        private void btnInsert_Click(object sender, EventArgs e)
        {
          /*  SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                string query = "INSERT INTO CustomerForm_tbl (column1, column2) VALUES ('someData1', 'someData2')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Data inserted successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            } */
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                MessageBox.Show("Connection Successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Failed: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

        }

        private void btnCustomerSearch_Click(object sender, EventArgs e)
        {
            //new CustomerSearchForm().Show();

        }

        private void btnBookingSearch_Click(object sender, EventArgs e)
        {
            new BookingSearchForm().Show();

        }

        private void btnCancellation_Click(object sender, EventArgs e)
        {
           new CancellationForm().Show();

        }

        private void btnLoyaltyProgram_Click_1(object sender, EventArgs e)
        {
            // new LoyaltyProgramForm().Show();

        }

        private void btnSchedule_Click(object sender, EventArgs e)
        {
          new ScheduleForm().Show();

        }

        private void label1_Click(object sender, EventArgs e)
        {
            login Login = new login();
            Login.Show();
        }

        private void train_Click(object sender, EventArgs e)
        {
            new TrainBookingForm().Show();

        }

        private void hotel_Click(object sender, EventArgs e)
        {
            new HotelBookingForm().Show();

        }

        private void payment_Click(object sender, EventArgs e)
        {
            new PaymentForm().Show();

        }
    }
}