﻿
namespace travel
{
    partial class HotelBookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.payment = new System.Windows.Forms.Label();
            this.hotel = new System.Windows.Forms.Label();
            this.train = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.hotelbook = new System.Windows.Forms.Label();
            this.textBoxCustomerID = new System.Windows.Forms.TextBox();
            this.textBoxPricePerNight = new System.Windows.Forms.TextBox();
            this.dateTimePickerCheckInDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerCheckOutDate = new System.Windows.Forms.DateTimePicker();
            this.CustomerID = new System.Windows.Forms.Label();
            this.BookingID = new System.Windows.Forms.Label();
            this.CheckInDate = new System.Windows.Forms.Label();
            this.CheckOutDate = new System.Windows.Forms.Label();
            this.btnBookHotel = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxBookingID = new System.Windows.Forms.TextBox();
            this.dataGridViewBookings = new System.Windows.Forms.DataGridView();
            this.comboBoxHotelName = new System.Windows.Forms.ComboBox();
            this.buttonConfirmBooking = new System.Windows.Forms.Button();
            this.comboBoxNumberOfRooms = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTotalAmount = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookings)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 611);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 17);
            this.label5.TabIndex = 60;
            this.label5.Text = "logout";
            // 
            // payment
            // 
            this.payment.AutoSize = true;
            this.payment.Location = new System.Drawing.Point(89, 510);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(74, 17);
            this.payment.TabIndex = 59;
            this.payment.Text = "PAYMENT";
            // 
            // hotel
            // 
            this.hotel.AutoSize = true;
            this.hotel.Location = new System.Drawing.Point(89, 415);
            this.hotel.Name = "hotel";
            this.hotel.Size = new System.Drawing.Size(123, 17);
            this.hotel.TabIndex = 58;
            this.hotel.Text = "HOTEL BOOKING";
            // 
            // train
            // 
            this.train.AutoSize = true;
            this.train.Location = new System.Drawing.Point(88, 322);
            this.train.Name = "train";
            this.train.Size = new System.Drawing.Size(117, 17);
            this.train.TabIndex = 57;
            this.train.Text = "TRAIN BOOKING";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 220);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 56;
            this.label1.Text = "Login";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::travel.Properties.Resources.l1;
            this.pictureBox6.Location = new System.Drawing.Point(12, 595);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 55;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::travel.Properties.Resources.pay;
            this.pictureBox5.Location = new System.Drawing.Point(11, 490);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 54;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::travel.Properties.Resources.hotel;
            this.pictureBox4.Location = new System.Drawing.Point(11, 393);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 53;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::travel.Properties.Resources.trainmanage;
            this.pictureBox3.Location = new System.Drawing.Point(11, 300);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 52;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::travel.Properties.Resources.login1;
            this.pictureBox2.Location = new System.Drawing.Point(12, 198);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 51;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::travel.Properties.Resources.Travel_agency__1__removebg_preview__2_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(159, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 50;
            this.pictureBox1.TabStop = false;
            // 
            // hotelbook
            // 
            this.hotelbook.AutoSize = true;
            this.hotelbook.BackColor = System.Drawing.Color.PeachPuff;
            this.hotelbook.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelbook.ForeColor = System.Drawing.Color.LightCoral;
            this.hotelbook.Location = new System.Drawing.Point(464, 35);
            this.hotelbook.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.hotelbook.Name = "hotelbook";
            this.hotelbook.Size = new System.Drawing.Size(230, 69);
            this.hotelbook.TabIndex = 61;
            this.hotelbook.Text = "HOTEL";
            // 
            // textBoxCustomerID
            // 
            this.textBoxCustomerID.Location = new System.Drawing.Point(384, 198);
            this.textBoxCustomerID.MaximumSize = new System.Drawing.Size(500, 500);
            this.textBoxCustomerID.Name = "textBoxCustomerID";
            this.textBoxCustomerID.Size = new System.Drawing.Size(198, 22);
            this.textBoxCustomerID.TabIndex = 62;
            // 
            // textBoxPricePerNight
            // 
            this.textBoxPricePerNight.Location = new System.Drawing.Point(384, 346);
            this.textBoxPricePerNight.MaximumSize = new System.Drawing.Size(500, 500);
            this.textBoxPricePerNight.Name = "textBoxPricePerNight";
            this.textBoxPricePerNight.Size = new System.Drawing.Size(198, 22);
            this.textBoxPricePerNight.TabIndex = 63;
            // 
            // dateTimePickerCheckInDate
            // 
            this.dateTimePickerCheckInDate.Location = new System.Drawing.Point(384, 393);
            this.dateTimePickerCheckInDate.MaximumSize = new System.Drawing.Size(500, 500);
            this.dateTimePickerCheckInDate.Name = "dateTimePickerCheckInDate";
            this.dateTimePickerCheckInDate.Size = new System.Drawing.Size(198, 22);
            this.dateTimePickerCheckInDate.TabIndex = 65;
            // 
            // dateTimePickerCheckOutDate
            // 
            this.dateTimePickerCheckOutDate.Location = new System.Drawing.Point(384, 447);
            this.dateTimePickerCheckOutDate.MaximumSize = new System.Drawing.Size(500, 500);
            this.dateTimePickerCheckOutDate.Name = "dateTimePickerCheckOutDate";
            this.dateTimePickerCheckOutDate.Size = new System.Drawing.Size(198, 22);
            this.dateTimePickerCheckOutDate.TabIndex = 66;
            // 
            // CustomerID
            // 
            this.CustomerID.AutoSize = true;
            this.CustomerID.Location = new System.Drawing.Point(262, 189);
            this.CustomerID.MaximumSize = new System.Drawing.Size(500, 500);
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.Size = new System.Drawing.Size(81, 17);
            this.CustomerID.TabIndex = 67;
            this.CustomerID.Text = "CustomerID";
            // 
            // BookingID
            // 
            this.BookingID.AutoSize = true;
            this.BookingID.Location = new System.Drawing.Point(262, 241);
            this.BookingID.MaximumSize = new System.Drawing.Size(500, 500);
            this.BookingID.Name = "BookingID";
            this.BookingID.Size = new System.Drawing.Size(72, 17);
            this.BookingID.TabIndex = 68;
            this.BookingID.Text = "BookingID";
            // 
            // CheckInDate
            // 
            this.CheckInDate.AutoSize = true;
            this.CheckInDate.Location = new System.Drawing.Point(262, 395);
            this.CheckInDate.MaximumSize = new System.Drawing.Size(500, 500);
            this.CheckInDate.Name = "CheckInDate";
            this.CheckInDate.Size = new System.Drawing.Size(96, 17);
            this.CheckInDate.TabIndex = 70;
            this.CheckInDate.Text = "Check In Date";
            // 
            // CheckOutDate
            // 
            this.CheckOutDate.AutoSize = true;
            this.CheckOutDate.Location = new System.Drawing.Point(262, 447);
            this.CheckOutDate.MaximumSize = new System.Drawing.Size(500, 500);
            this.CheckOutDate.Name = "CheckOutDate";
            this.CheckOutDate.Size = new System.Drawing.Size(108, 17);
            this.CheckOutDate.TabIndex = 71;
            this.CheckOutDate.Text = "Check Out Date";
            // 
            // btnBookHotel
            // 
            this.btnBookHotel.Location = new System.Drawing.Point(762, 564);
            this.btnBookHotel.Name = "btnBookHotel";
            this.btnBookHotel.Size = new System.Drawing.Size(81, 64);
            this.btnBookHotel.TabIndex = 72;
            this.btnBookHotel.Text = "Book Hotel";
            this.btnBookHotel.UseVisualStyleBackColor = true;
            this.btnBookHotel.Click += new System.EventHandler(this.btnBookHotel_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::travel.Properties.Resources.back;
            this.pictureBox7.Location = new System.Drawing.Point(1071, 568);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(71, 60);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 73;
            this.pictureBox7.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(262, 300);
            this.label2.MaximumSize = new System.Drawing.Size(500, 500);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 74;
            this.label2.Text = "HotelName";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(262, 346);
            this.label7.MaximumSize = new System.Drawing.Size(500, 500);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 17);
            this.label7.TabIndex = 78;
            this.label7.Text = "PricePerNight";
            // 
            // textBoxBookingID
            // 
            this.textBoxBookingID.Location = new System.Drawing.Point(398, 241);
            this.textBoxBookingID.Name = "textBoxBookingID";
            this.textBoxBookingID.Size = new System.Drawing.Size(98, 22);
            this.textBoxBookingID.TabIndex = 81;
            // 
            // dataGridViewBookings
            // 
            this.dataGridViewBookings.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBookings.GridColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewBookings.Location = new System.Drawing.Point(756, 171);
            this.dataGridViewBookings.Name = "dataGridViewBookings";
            this.dataGridViewBookings.RowHeadersWidth = 51;
            this.dataGridViewBookings.RowTemplate.Height = 24;
            this.dataGridViewBookings.Size = new System.Drawing.Size(395, 316);
            this.dataGridViewBookings.TabIndex = 82;
            // 
            // comboBoxHotelName
            // 
            this.comboBoxHotelName.FormattingEnabled = true;
            this.comboBoxHotelName.Location = new System.Drawing.Point(384, 300);
            this.comboBoxHotelName.Name = "comboBoxHotelName";
            this.comboBoxHotelName.Size = new System.Drawing.Size(121, 24);
            this.comboBoxHotelName.TabIndex = 83;
            this.comboBoxHotelName.SelectedIndexChanged += new System.EventHandler(this.comboBoxHotelName_SelectedIndexChanged);
            // 
            // buttonConfirmBooking
            // 
            this.buttonConfirmBooking.Location = new System.Drawing.Point(613, 568);
            this.buttonConfirmBooking.Name = "buttonConfirmBooking";
            this.buttonConfirmBooking.Size = new System.Drawing.Size(81, 64);
            this.buttonConfirmBooking.TabIndex = 84;
            this.buttonConfirmBooking.Text = "Confirm Booking";
            this.buttonConfirmBooking.UseVisualStyleBackColor = true;
            // 
            // comboBoxNumberOfRooms
            // 
            this.comboBoxNumberOfRooms.FormattingEnabled = true;
            this.comboBoxNumberOfRooms.Location = new System.Drawing.Point(384, 503);
            this.comboBoxNumberOfRooms.Name = "comboBoxNumberOfRooms";
            this.comboBoxNumberOfRooms.Size = new System.Drawing.Size(121, 24);
            this.comboBoxNumberOfRooms.TabIndex = 85;
            this.comboBoxNumberOfRooms.SelectedIndexChanged += new System.EventHandler(this.AviliableRooms_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(262, 503);
            this.label3.MaximumSize = new System.Drawing.Size(500, 500);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 17);
            this.label3.TabIndex = 86;
            this.label3.Text = "NumberOfRooms";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(265, 553);
            this.label4.MaximumSize = new System.Drawing.Size(500, 500);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 17);
            this.label4.TabIndex = 87;
            this.label4.Text = "Total Amount";
            // 
            // textBoxTotalAmount
            // 
            this.textBoxTotalAmount.Location = new System.Drawing.Point(384, 553);
            this.textBoxTotalAmount.Name = "textBoxTotalAmount";
            this.textBoxTotalAmount.Size = new System.Drawing.Size(98, 22);
            this.textBoxTotalAmount.TabIndex = 88;
            // 
            // HotelBookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.textBoxTotalAmount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxNumberOfRooms);
            this.Controls.Add(this.buttonConfirmBooking);
            this.Controls.Add(this.comboBoxHotelName);
            this.Controls.Add(this.dataGridViewBookings);
            this.Controls.Add(this.textBoxBookingID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.btnBookHotel);
            this.Controls.Add(this.CheckOutDate);
            this.Controls.Add(this.CheckInDate);
            this.Controls.Add(this.BookingID);
            this.Controls.Add(this.CustomerID);
            this.Controls.Add(this.dateTimePickerCheckOutDate);
            this.Controls.Add(this.dateTimePickerCheckInDate);
            this.Controls.Add(this.textBoxPricePerNight);
            this.Controls.Add(this.textBoxCustomerID);
            this.Controls.Add(this.hotelbook);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.hotel);
            this.Controls.Add(this.train);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "HotelBookingForm";
            this.Text = "HotelBookingForm";
            this.Load += new System.EventHandler(this.HotelBookingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookings)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label payment;
        private System.Windows.Forms.Label hotel;
        private System.Windows.Forms.Label train;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label hotelbook;
        private System.Windows.Forms.TextBox textBoxCustomerID;
        private System.Windows.Forms.TextBox textBoxPricePerNight;
        private System.Windows.Forms.DateTimePicker dateTimePickerCheckInDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerCheckOutDate;
        private System.Windows.Forms.Label CustomerID;
        private System.Windows.Forms.Label BookingID;
        private System.Windows.Forms.Label CheckInDate;
        private System.Windows.Forms.Label CheckOutDate;
        private System.Windows.Forms.Button btnBookHotel;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxBookingID;
        private System.Windows.Forms.DataGridView dataGridViewBookings;
        private System.Windows.Forms.ComboBox comboBoxHotelName;
        private System.Windows.Forms.Button buttonConfirmBooking;
        private System.Windows.Forms.ComboBox comboBoxNumberOfRooms;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTotalAmount;
    }
}