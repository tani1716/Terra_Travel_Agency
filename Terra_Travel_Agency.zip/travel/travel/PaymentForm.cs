﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace travel
{
    public partial class PaymentForm : Form
    {
        private DataAccess dataAccess;
        private decimal totalAmount;

        // Constructor to accept total amount
        public PaymentForm(decimal totalAmount)
        {
            InitializeComponent();
            this.totalAmount = totalAmount;

            // You can display totalAmount in a TextBox or Label, for example:
            txtTotalAmount.Text = totalAmount.ToString("C");  // C for currency format
        }

        public PaymentForm()
        {
            InitializeComponent(); // Sets up the UI components for the form
            dataAccess = new DataAccess(); // Create an instance of DataAccess
        }

        private void btnProcessUPIPayment_Click(object sender, EventArgs e)
        { // Get the UPI ID from the form
            string upiID = txtUPIID.Text;

            // Check if the UPI ID is empty
            if (string.IsNullOrEmpty(upiID))
            {
                MessageBox.Show("Please enter your UPI ID.");
                return; // Exit the method if UPI ID is missing
            }

            // Save UPI payment details to the database
           // dataAccess.SaveUPIPayment(upiID); // Call the method to save UPI payment details
            dataAccess.SaveUPIPayment(); // Call the method to save UPI payment details

            // Show a success message
            MessageBox.Show("UPI payment processed successfully!"); // Success message
        }


        // This method simulates processing the UPI payment
        private void ProcessUPIPayment(string upiID)
        {
            // Here, we assume that the payment always works. 
            // In a real application, you would connect to a payment service here.

            // For demonstration, we show a success message
            MessageBox.Show("UPI payment processed successfully!"); // Success message

            // If you want to simulate a failure, you could uncomment the line below:
            // MessageBox.Show("UPI payment failed. Please try again."); // Failure message
        }

        private void PaymentForm_Load(object sender, EventArgs e)
        {

        }
    }


}
