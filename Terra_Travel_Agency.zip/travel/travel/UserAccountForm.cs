﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace travel
{
    public partial class UserAccountForm : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";

        DataAccess dataAccess = new DataAccess();
        int selectedUserID = 0;  // To track the selected UserID for update and delete actions

        public UserAccountForm()
        {
            InitializeComponent();
            LoadUsers(); // Load users when the form is initialized
        }

        private void UserAccountForm_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)  // Ensure that a valid row is clicked
            {
                // Get the selected row
                DataGridViewRow row = dataGridViewUsers.Rows[e.RowIndex];

                // Load the selected row data into the form fields
                selectedUserID = Convert.ToInt32(row.Cells["UserID"].Value); // Store UserID for updating
                txtUsername.Text = row.Cells["Username"].Value.ToString();   // Fill Username TextBox
                txtPassword.Text = row.Cells["Password"].Value.ToString();   // Fill Password TextBox
                cmbRole.SelectedItem = row.Cells["Role"].Value.ToString();   // Fill Role ComboBox
                txtEmail.Text = row.Cells["Email"].Value.ToString();         // Fill Email TextBox
            }
        }


            // Method to load users into the DataGridView
            private void LoadUsers()
            {
                // Logic to load users from database into dataGridViewUsers
                // Example:
                using (SqlConnection connection = new SqlConnection("your_connection_string_here"))
                {
                    connection.Open();

                    string query = "SELECT * FROM Users_info_tbl";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridViewUsers.DataSource = dt;
                    }
                }
            }
        



        private void AddUser()
        {
            // Validate that all required fields are filled
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) || cmbRole.SelectedItem == null)
            {
                MessageBox.Show("Please fill all the required fields.");
                return;
            }

            // Add the user to the database
            try
            {
                using (SqlConnection connection = new SqlConnection("your_connection_string_here"))
                {
                    connection.Open();

                    string query = "INSERT INTO Users_info_tbl (Username, Password, Role, Email) VALUES (@Username, @Password, @Role, @Email)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("Username", txtUsername.Text);
                        command.Parameters.AddWithValue("Password", txtPassword.Text);
                        command.Parameters.AddWithValue("Role", cmbRole.SelectedItem.ToString());
                        command.Parameters.AddWithValue("Email", txtEmail.Text);

                        command.ExecuteNonQuery();
                    }
                }

                // Optionally refresh the DataGridView
                LoadUsers();
                MessageBox.Show("User added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void UpdateUser()
        {
            // Validate that all required fields are filled
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) || cmbRole.SelectedItem == null)
            {
                MessageBox.Show("Please fill all the required fields.");
                return;
            }

            // Update the user in the database
            try
            {
                using (SqlConnection connection = new SqlConnection("your_connection_string_here"))
                {
                    connection.Open();

                    string query = "UPDATE Users_info_tbl SET Username = @Username, Password = @Password, Role = @Role, Email = @Email WHERE UserID = @UserID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("Username", txtUsername.Text);
                        command.Parameters.AddWithValue("Password", txtPassword.Text);
                        command.Parameters.AddWithValue("Role", cmbRole.SelectedItem.ToString());
                        command.Parameters.AddWithValue("Email", txtEmail.Text);
                        command.Parameters.AddWithValue("UserID", selectedUserID);

                        command.ExecuteNonQuery();
                    }
                }

                // Optionally refresh the DataGridView
                LoadUsers();
                MessageBox.Show("User updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void DeleteUser()
        {
            // Confirm deletion
            if (MessageBox.Show("Are you sure you want to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection("your_connection_string_here"))
                    {
                        connection.Open();

                        string query = "DELETE FROM Users_info_tbl WHERE UserID = @UserID";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("UserID", selectedUserID);
                            command.ExecuteNonQuery();
                        }
                    }

                    // Optionally refresh the DataGridView
                    LoadUsers();
                    MessageBox.Show("User deleted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        
    }
}

 