﻿
namespace travel
{
    partial class TrainManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxRouteFrom = new System.Windows.Forms.TextBox();
            this.textBoxRouteTo = new System.Windows.Forms.TextBox();
            this.textBoxPricePerSeat = new System.Windows.Forms.TextBox();
            this.btnSearchTrain = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TrainDataGridView = new System.Windows.Forms.DataGridView();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnhotel = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.train = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.ROUTEFROM = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxTotalSeats = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dateTimePickerDeparture = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerArrival = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxTrainName = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.TrainDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxRouteFrom
            // 
            this.textBoxRouteFrom.Location = new System.Drawing.Point(406, 184);
            this.textBoxRouteFrom.Name = "textBoxRouteFrom";
            this.textBoxRouteFrom.Size = new System.Drawing.Size(47, 22);
            this.textBoxRouteFrom.TabIndex = 1;
            // 
            // textBoxRouteTo
            // 
            this.textBoxRouteTo.Location = new System.Drawing.Point(571, 187);
            this.textBoxRouteTo.Name = "textBoxRouteTo";
            this.textBoxRouteTo.Size = new System.Drawing.Size(51, 22);
            this.textBoxRouteTo.TabIndex = 2;
            this.textBoxRouteTo.TextChanged += new System.EventHandler(this.txtArrival_TextChanged);
            // 
            // textBoxPricePerSeat
            // 
            this.textBoxPricePerSeat.Location = new System.Drawing.Point(476, 395);
            this.textBoxPricePerSeat.Name = "textBoxPricePerSeat";
            this.textBoxPricePerSeat.Size = new System.Drawing.Size(100, 22);
            this.textBoxPricePerSeat.TabIndex = 3;
            // 
            // btnSearchTrain
            // 
            this.btnSearchTrain.BackColor = System.Drawing.Color.Tomato;
            this.btnSearchTrain.Location = new System.Drawing.Point(954, 150);
            this.btnSearchTrain.Name = "btnSearchTrain";
            this.btnSearchTrain.Size = new System.Drawing.Size(61, 48);
            this.btnSearchTrain.TabIndex = 6;
            this.btnSearchTrain.Text = "search";
            this.btnSearchTrain.UseVisualStyleBackColor = false;
            this.btnSearchTrain.Click += new System.EventHandler(this.btnSearchTrain_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(347, 252);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Train Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(360, 441);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Seats";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(347, 395);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Price/Seat";
            // 
            // TrainDataGridView
            // 
            this.TrainDataGridView.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.TrainDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TrainDataGridView.Location = new System.Drawing.Point(772, 217);
            this.TrainDataGridView.Name = "TrainDataGridView";
            this.TrainDataGridView.RowHeadersWidth = 51;
            this.TrainDataGridView.RowTemplate.Height = 24;
            this.TrainDataGridView.Size = new System.Drawing.Size(371, 336);
            this.TrainDataGridView.TabIndex = 11;
            // 
            // txtsearch
            // 
            this.txtsearch.BackColor = System.Drawing.Color.Tomato;
            this.txtsearch.Location = new System.Drawing.Point(1043, 150);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(100, 22);
            this.txtsearch.TabIndex = 12;
            // 
            // btnhotel
            // 
            this.btnhotel.BackColor = System.Drawing.Color.Tomato;
            this.btnhotel.Location = new System.Drawing.Point(457, 573);
            this.btnhotel.Name = "btnhotel";
            this.btnhotel.Size = new System.Drawing.Size(133, 52);
            this.btnhotel.TabIndex = 13;
            this.btnhotel.Text = "Hotel Boooking";
            this.btnhotel.UseVisualStyleBackColor = false;
            this.btnhotel.Click += new System.EventHandler(this.btnhotel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 608);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 17);
            this.label5.TabIndex = 38;
            this.label5.Text = "logout";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(109, 507);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 17);
            this.label6.TabIndex = 37;
            this.label6.Text = "system logs";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(109, 412);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "staff management";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(108, 319);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 17);
            this.label8.TabIndex = 35;
            this.label8.Text = "train management";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(109, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 17);
            this.label9.TabIndex = 34;
            this.label9.Text = "Login";
            // 
            // train
            // 
            this.train.AutoSize = true;
            this.train.BackColor = System.Drawing.Color.PeachPuff;
            this.train.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.train.ForeColor = System.Drawing.Color.LightCoral;
            this.train.Location = new System.Drawing.Point(421, 21);
            this.train.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.train.Name = "train";
            this.train.Size = new System.Drawing.Size(656, 69);
            this.train.TabIndex = 39;
            this.train.Text = "TRAIN MANAGEMENT";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::travel.Properties.Resources.l1;
            this.pictureBox6.Location = new System.Drawing.Point(32, 592);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 33;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::travel.Properties.Resources.systemlog;
            this.pictureBox5.Location = new System.Drawing.Point(31, 487);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 32;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::travel.Properties.Resources.staffmanage;
            this.pictureBox4.Location = new System.Drawing.Point(31, 390);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 31;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::travel.Properties.Resources.trainmanage;
            this.pictureBox3.Location = new System.Drawing.Point(31, 297);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::travel.Properties.Resources.login1;
            this.pictureBox2.Location = new System.Drawing.Point(32, 195);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::travel.Properties.Resources.Travel_agency__1__removebg_preview__2_;
            this.pictureBox1.Location = new System.Drawing.Point(32, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(159, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::travel.Properties.Resources.back;
            this.pictureBox7.Location = new System.Drawing.Point(1072, 582);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(71, 60);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 41;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // ROUTEFROM
            // 
            this.ROUTEFROM.AutoSize = true;
            this.ROUTEFROM.Location = new System.Drawing.Point(347, 184);
            this.ROUTEFROM.Name = "ROUTEFROM";
            this.ROUTEFROM.Size = new System.Drawing.Size(36, 17);
            this.ROUTEFROM.TabIndex = 43;
            this.ROUTEFROM.Text = "from";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(510, 187);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 17);
            this.label10.TabIndex = 44;
            this.label10.Text = "to";
            // 
            // textBoxTotalSeats
            // 
            this.textBoxTotalSeats.Location = new System.Drawing.Point(476, 441);
            this.textBoxTotalSeats.Name = "textBoxTotalSeats";
            this.textBoxTotalSeats.Size = new System.Drawing.Size(100, 22);
            this.textBoxTotalSeats.TabIndex = 45;
            this.textBoxTotalSeats.TextChanged += new System.EventHandler(this.textBoxSeats_TextChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Tomato;
            this.btnAdd.Location = new System.Drawing.Point(315, 501);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(81, 54);
            this.btnAdd.TabIndex = 46;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Tomato;
            this.btnUpdate.Location = new System.Drawing.Point(316, 571);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(80, 54);
            this.btnUpdate.TabIndex = 47;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Tomato;
            this.btnDelete.Location = new System.Drawing.Point(457, 501);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(82, 54);
            this.btnDelete.TabIndex = 48;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dateTimePickerDeparture
            // 
            this.dateTimePickerDeparture.Location = new System.Drawing.Point(476, 297);
            this.dateTimePickerDeparture.Name = "dateTimePickerDeparture";
            this.dateTimePickerDeparture.Size = new System.Drawing.Size(170, 22);
            this.dateTimePickerDeparture.TabIndex = 49;
            // 
            // dateTimePickerArrival
            // 
            this.dateTimePickerArrival.Location = new System.Drawing.Point(476, 347);
            this.dateTimePickerArrival.Name = "dateTimePickerArrival";
            this.dateTimePickerArrival.Size = new System.Drawing.Size(170, 22);
            this.dateTimePickerArrival.TabIndex = 50;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(347, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 51;
            this.label2.Text = "Departure";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(360, 347);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 17);
            this.label11.TabIndex = 52;
            this.label11.Text = "Arrival";
            // 
            // textBoxTrainName
            // 
            this.textBoxTrainName.Location = new System.Drawing.Point(476, 249);
            this.textBoxTrainName.Name = "textBoxTrainName";
            this.textBoxTrainName.Size = new System.Drawing.Size(100, 22);
            this.textBoxTrainName.TabIndex = 53;
            // 
            // TrainManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.textBoxTrainName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePickerArrival);
            this.Controls.Add(this.dateTimePickerDeparture);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.textBoxTotalSeats);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ROUTEFROM);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.train);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnhotel);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.TrainDataGridView);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSearchTrain);
            this.Controls.Add(this.textBoxPricePerSeat);
            this.Controls.Add(this.textBoxRouteTo);
            this.Controls.Add(this.textBoxRouteFrom);
            this.Name = "TrainManagementForm";
            this.Text = "TrainManagementForm";
            this.Load += new System.EventHandler(this.TrainManagementForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TrainDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBoxRouteFrom;
        private System.Windows.Forms.TextBox textBoxRouteTo;
        private System.Windows.Forms.TextBox textBoxPricePerSeat;
        private System.Windows.Forms.Button btnSearchTrain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView TrainDataGridView;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnhotel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label train;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label ROUTEFROM;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxTotalSeats;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DateTimePicker dateTimePickerDeparture;
        private System.Windows.Forms.DateTimePicker dateTimePickerArrival;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxTrainName;
    }
}