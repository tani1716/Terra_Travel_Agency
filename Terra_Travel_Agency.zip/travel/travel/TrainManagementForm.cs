﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class TrainManagementForm : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";
        int selectedId = -1;



        public TrainManagementForm()
        {
            InitializeComponent();
            LoadTrainData();
        }

        private void TrainManagementForm_Load(object sender, EventArgs e)
        {
    
        }

        private void btnAddTrain_Click(object sender, EventArgs e)
        {
          
            AddTrain();

        }


        private void btnSearchTrain_Click(object sender, EventArgs e)
        {
           
        }

        public DataTable SearchTrain()
        {
            // Set a fixed search term or use another way to define what to search for
            string searchTerm = txtsearch.Text; // You can keep the term here to be dynamic, as it depends on the textbox input

            DataTable trainsTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM Train_management_tbl WHERE TrainName = '" + searchTerm + "'";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(trainsTable);
                }
                catch (Exception ex)
                {
                    throw new Exception("Error searching for trains: " + ex.Message);
                }
            }

            return trainsTable;
        }


        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnhotel_Click(object sender, EventArgs e)
        {
            // Open the HotelManagementForm
            HotelManagementForm hotelManagementForm = new HotelManagementForm();
            hotelManagementForm.Show(); // Opens the form
        }
      

        private void txtArrival_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxTrainName_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void textBoxSeats_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            BookingForm bookingForm = new BookingForm();
            bookingForm.Show();
            this.Hide();
        }

        // Method to load train data into DataGridView
        //private void LoadTrainData()
        //{
        //    string query = "SELECT * FROM TrainManagement_tbl";
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
        //        {
        //            DataTable dataTable = new DataTable();
        //            try
        //            {
        //                adapter.Fill(dataTable);
        //                dataGridViewTrains.DataSource = dataTable;
        //            }
        //            catch (Exception ex)
        //            {
        //                MessageBox.Show("Error loading train data: " + ex.Message);
        //            }
        //        }
        //    }
        //}

        private void LoadTrainData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Train_management_tbl";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                TrainDataGridView.DataSource = dataTable;
            }
        }



        private void AddTrain()
        {
            // Format DateTime values properly for SQL Server
            string departureTime = dateTimePickerDeparture.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string arrivalTime = dateTimePickerArrival.Value.ToString("yyyy-MM-dd HH:mm:ss");

            string query = "INSERT INTO Train_management_tbl (TrainName, RouteFrom, RouteTo, DepartureTime, ArrivalTime, PricePerSeat, TotalSeats) " +
                           "VALUES ('" + textBoxTrainName.Text + "', '" + textBoxRouteFrom.Text + "', '" + textBoxRouteTo.Text + "', '" +
                           departureTime + "', '" + arrivalTime + "', '" + textBoxPricePerSeat.Text + "', '" +
                           textBoxTotalSeats.Text + "')";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Train added successfully!");
                        LoadTrainData(); // Refresh the grid
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error adding train: " + ex.Message);
                    }
                }
            }
        }

        // Method to update an existing train
        private void UpdateTrain(int trainId)
        {
            string query = "UPDATE Train_management_tbl SET TrainName = '" + textBoxTrainName.Text + "', RouteFrom = '" + textBoxRouteFrom.Text +
                           "', RouteTo = '" + textBoxRouteTo.Text + "', DepartureTime = '" + dateTimePickerDeparture.Value +
                           "', ArrivalTime = '" + dateTimePickerArrival.Value + "', PricePerSeat = '" + textBoxPricePerSeat.Text +
                           "', TotalSeats = '" + textBoxTotalSeats.Text + "' WHERE TrainID = " + trainId;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Train updated successfully!");
                        LoadTrainData(); // Refresh the grid
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating train: " + ex.Message);
                    }
                }
            }
        }

        // Method to delete a train
        private void DeleteTrain(int trainId)
        {
            string query = "DELETE FROM Train_management_tbl WHERE TrainID = " + trainId;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Train deleted successfully!");
                        LoadTrainData(); // Refresh the grid
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting train: " + ex.Message);
                    }
                }
            }
        }
        
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddTrain();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (TrainDataGridView.SelectedRows.Count > 0)
            {
                int trainId = Convert.ToInt32(TrainDataGridView.SelectedRows[0].Cells["TrainID"].Value);
                UpdateTrain(trainId);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (TrainDataGridView.SelectedRows.Count > 0)
            {
                int trainId = Convert.ToInt32(TrainDataGridView.SelectedRows[0].Cells["TrainID"].Value);
                DeleteTrain(trainId);
            }
        }
    }
}
