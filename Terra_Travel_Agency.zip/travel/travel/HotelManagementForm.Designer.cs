﻿
namespace travel
{
    partial class HotelManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxHotelName = new System.Windows.Forms.TextBox();
            this.textBoxLocation = new System.Windows.Forms.TextBox();
            this.textBoxPricePerNight = new System.Windows.Forms.TextBox();
            this.textBoxAvailableRooms = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddHotel = new System.Windows.Forms.Button();
            this.btnSearchHotel = new System.Windows.Forms.Button();
            this.textBoxSearchHotel = new System.Windows.Forms.TextBox();
            this.dataGridViewHotels = new System.Windows.Forms.DataGridView();
            this.btnreport = new System.Windows.Forms.Button();
            this.textBoxHotelID = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHotels)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxHotelName
            // 
            this.textBoxHotelName.Location = new System.Drawing.Point(405, 87);
            this.textBoxHotelName.Name = "textBoxHotelName";
            this.textBoxHotelName.Size = new System.Drawing.Size(100, 22);
            this.textBoxHotelName.TabIndex = 0;
            // 
            // textBoxLocation
            // 
            this.textBoxLocation.Location = new System.Drawing.Point(405, 144);
            this.textBoxLocation.Name = "textBoxLocation";
            this.textBoxLocation.Size = new System.Drawing.Size(100, 22);
            this.textBoxLocation.TabIndex = 1;
            // 
            // textBoxPricePerNight
            // 
            this.textBoxPricePerNight.Location = new System.Drawing.Point(405, 202);
            this.textBoxPricePerNight.Name = "textBoxPricePerNight";
            this.textBoxPricePerNight.Size = new System.Drawing.Size(100, 22);
            this.textBoxPricePerNight.TabIndex = 2;
            // 
            // textBoxAvailableRooms
            // 
            this.textBoxAvailableRooms.Location = new System.Drawing.Point(405, 271);
            this.textBoxAvailableRooms.Name = "textBoxAvailableRooms";
            this.textBoxAvailableRooms.Size = new System.Drawing.Size(100, 22);
            this.textBoxAvailableRooms.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(296, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Hotel Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Location";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(296, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Price per Night";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Aviliable Rooms";
            // 
            // btnAddHotel
            // 
            this.btnAddHotel.BackColor = System.Drawing.Color.Tomato;
            this.btnAddHotel.Location = new System.Drawing.Point(312, 405);
            this.btnAddHotel.Name = "btnAddHotel";
            this.btnAddHotel.Size = new System.Drawing.Size(105, 73);
            this.btnAddHotel.TabIndex = 8;
            this.btnAddHotel.Text = "Add Hotel";
            this.btnAddHotel.UseVisualStyleBackColor = false;
            this.btnAddHotel.Click += new System.EventHandler(this.btnAddHotel_Click);
            // 
            // btnSearchHotel
            // 
            this.btnSearchHotel.BackColor = System.Drawing.Color.Tomato;
            this.btnSearchHotel.Location = new System.Drawing.Point(312, 509);
            this.btnSearchHotel.Name = "btnSearchHotel";
            this.btnSearchHotel.Size = new System.Drawing.Size(95, 85);
            this.btnSearchHotel.TabIndex = 9;
            this.btnSearchHotel.Text = "Search Hotel";
            this.btnSearchHotel.UseVisualStyleBackColor = false;
            this.btnSearchHotel.Click += new System.EventHandler(this.btnSearchHotel_Click);
            // 
            // textBoxSearchHotel
            // 
            this.textBoxSearchHotel.BackColor = System.Drawing.Color.Tomato;
            this.textBoxSearchHotel.Location = new System.Drawing.Point(442, 540);
            this.textBoxSearchHotel.Name = "textBoxSearchHotel";
            this.textBoxSearchHotel.Size = new System.Drawing.Size(100, 22);
            this.textBoxSearchHotel.TabIndex = 10;
            // 
            // dataGridViewHotels
            // 
            this.dataGridViewHotels.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewHotels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHotels.Location = new System.Drawing.Point(606, 87);
            this.dataGridViewHotels.Name = "dataGridViewHotels";
            this.dataGridViewHotels.RowHeadersWidth = 51;
            this.dataGridViewHotels.RowTemplate.Height = 24;
            this.dataGridViewHotels.Size = new System.Drawing.Size(505, 286);
            this.dataGridViewHotels.TabIndex = 11;
            this.dataGridViewHotels.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHotels_CellClick);
            this.dataGridViewHotels.SelectionChanged += new System.EventHandler(this.dataGridViewHotels_SelectionChanged);
            // 
            // btnreport
            // 
            this.btnreport.BackColor = System.Drawing.Color.Tomato;
            this.btnreport.Location = new System.Drawing.Point(976, 505);
            this.btnreport.Name = "btnreport";
            this.btnreport.Size = new System.Drawing.Size(121, 89);
            this.btnreport.TabIndex = 12;
            this.btnreport.Text = "Report";
            this.btnreport.UseVisualStyleBackColor = false;
            this.btnreport.Click += new System.EventHandler(this.btnreport_Click);
            // 
            // textBoxHotelID
            // 
            this.textBoxHotelID.Location = new System.Drawing.Point(416, 323);
            this.textBoxHotelID.Name = "textBoxHotelID";
            this.textBoxHotelID.Size = new System.Drawing.Size(100, 22);
            this.textBoxHotelID.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Tomato;
            this.button1.Location = new System.Drawing.Point(620, 418);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 73);
            this.button1.TabIndex = 14;
            this.button1.Text = "Delete Hotel";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Tomato;
            this.button2.Location = new System.Drawing.Point(478, 418);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 73);
            this.button2.TabIndex = 14;
            this.button2.Text = "Upadate Hotel";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // HotelManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1137, 646);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxHotelID);
            this.Controls.Add(this.btnreport);
            this.Controls.Add(this.dataGridViewHotels);
            this.Controls.Add(this.textBoxSearchHotel);
            this.Controls.Add(this.btnSearchHotel);
            this.Controls.Add(this.btnAddHotel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxAvailableRooms);
            this.Controls.Add(this.textBoxPricePerNight);
            this.Controls.Add(this.textBoxLocation);
            this.Controls.Add(this.textBoxHotelName);
            this.Name = "HotelManagementForm";
            this.Text = "HotelManagementForm";
            this.Load += new System.EventHandler(this.HotelManagementForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHotels)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxHotelName;
        private System.Windows.Forms.TextBox textBoxLocation;
        private System.Windows.Forms.TextBox textBoxPricePerNight;
        private System.Windows.Forms.TextBox textBoxAvailableRooms;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddHotel;
        private System.Windows.Forms.Button btnSearchHotel;
        private System.Windows.Forms.TextBox textBoxSearchHotel;
        private System.Windows.Forms.DataGridView dataGridViewHotels;
        private System.Windows.Forms.Button btnreport;
        private System.Windows.Forms.TextBox textBoxHotelID;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}