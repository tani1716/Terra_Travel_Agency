﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace travel
{
    public partial class login : Form
    {
                private DataAccess dataAccess = new DataAccess(); // Ensure this is correct

        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {
            cmbrole.Items.Clear();
            cmbrole.Items.Add("admin");
            cmbrole.Items.Add("user");
            cmbrole.SelectedIndex = 0;  // Default to "Admin"
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string username = this.username.Text;
            string password = this.password.Text;
            string role = cmbrole.SelectedItem.ToString();

         //   MessageBox.Show("Username: " + username + "\nPassword: " + password + "\nRole: " + role);

            // Check for admin login
            if (username == "abc" && password == "123" && role == "admin")
            {
                MessageBox.Show("Admin login successful!", "Login");

                adminsettings Adminsettings = new adminsettings();
                Adminsettings.Show(); // Use Show() to open non-modal, or ShowDialog() for modal
            }
            // Check for user login
            else if (username == "def" && password == "456" && role == "user")
            {
                MessageBox.Show("User login successful!", "Login");

                // Open MainForm and pass username and role
                MainForm mainForm = new MainForm(username, role);
                this.Hide();
                mainForm.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username, password, or role.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }
        void clear()
        {
            username.Text = "";
            password.Text = "";
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string username = this.username.Text;
            string password = this.password.Text;
            string role = cmbrole.SelectedItem.ToString();

            // Validation before signing up
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.", "Sign Up Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Call the SignUp method from DataAccess to insert the user into the database
            try
            {
               // dataAccess.SignupUser(username, password, role);
                dataAccess.SignupUser();

                MessageBox.Show("Sign up successful! You can now log in.", "Sign Up");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during sign up: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}