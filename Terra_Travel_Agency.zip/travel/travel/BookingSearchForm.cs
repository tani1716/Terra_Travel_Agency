﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class BookingSearchForm : Form
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";

        private int bookingId;
        private int userId;
        private int hotelId;
        private DateTime travelDate;
        private int customerId;
        private string bookingID;

        public BookingSearchForm()
        {
            InitializeComponent();
        }


        //private DataTable SearchBooking()
        //{
        //    DataTable dataTable = new DataTable();
        //    string searchTerm = txtSearch.Text; // Assuming there's a TextBox named txtSearch to get user input

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open(); // Open the database connection

        //        // SQL query to search for bookings
        //        string query = "SELECT * FROM Bookings WHERE Details LIKE '%' + Details + '%'"; // Modify based on your table structure

        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            // Parameters to the SQL query
        //            command.Parameters.Add(new SqlParameter("Details", "%" + searchTerm + "%")); // Using parameter without '@'

        //            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
        //            {
        //                adapter.Fill(dataTable); // Fill the DataTable with the results
        //            }
        //        }
        //    }

        //    return dataTable; // Return the populated DataTable
        //}




        private DataTable SearchBooking()
        {
            DataTable dataTable = new DataTable();
            string searchTerm = txtSearch.Text.Trim(); // Getting the search term from the user input (CustomerID)

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = @"
                    SELECT 
                        User_tbl.UserID,
                        Hotel_info_tbl.HotelID,
                        TrainBooking_tbl.BookingID,
                        TrainBooking_tbl.TravelDate
                    FROM 
                        User_tbl
                    INNER JOIN 
                        TrainBooking_tbl ON CustomerForm_tbl.CustomerID = TrainBooking_tbl.CustomerID
                    INNER JOIN 
                        Hotel_info_tbl ON TrainBooking_tbl.HotelID = Hotel_info_tbl.HotelID
                    INNER JOIN 
                        TrainBooking_info_tbl ON TrainBooking_tbl.BookingID = TrainBooking_tbl.BookingID
                    WHERE 
                        CustomerForm_tbl.CustomerID = " + customerId;

                SqlCommand command = new SqlCommand(query, connection);

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(dataTable);
                }
            }

            return dataTable;
        }

        private void LoadData()
        {
            DataTable dt = SearchBooking();

            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;

                foreach (DataRow row in dt.Rows)
                {
                    bookingId = Convert.ToInt32(row["BookingID"]);
                    userId = Convert.ToInt32(row["UserID"]);
                    hotelId = Convert.ToInt32(row["HotelID"]);
                    travelDate = Convert.ToDateTime(row["TravelDate"]);

                    StoreInBookings();
                }
            }
            else
            {
                MessageBox.Show("No records found for the entered Customer ID.");
            }
        }


        private void StoreInBookings()
        {
            string insertQuery = "INSERT INTO Bookings (BookingID, UserID, HotelID, TravelDate) " +
                                 "VALUES (" + bookingId + ", " + userId + ", " + hotelId + ", '" + travelDate.ToString("yyyy-MM-dd HH:mm:ss") + "')";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(insertQuery, connection);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error storing data: " + ex.Message);
                }
            }
        }

        private string CancelBooking()
        {
            if (string.IsNullOrWhiteSpace(bookingID))
            {
                return "Please enter a valid Booking ID.";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "DELETE FROM Bookings WHERE BookingID = " + bookingID;
                    SqlCommand command = new SqlCommand(query, connection);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return "Booking cancelled successfully.";
                    }
                    else
                    {
                        return "Booking not found or already cancelled.";
                    }
                }
                catch (Exception ex)
                {
                    return "Error cancelling booking: " + ex.Message;
                }
            }
        }


        private void BookingSearchForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSearchBooking_Click(object sender, EventArgs e)
        {
            int parsedCustomerId;
            if (int.TryParse(txtSearch.Text.Trim(), out parsedCustomerId))
            {
                customerId = parsedCustomerId;
                LoadData();
            }
            else
            {
                MessageBox.Show("Please enter a valid Customer ID.");
            }
        }
            

            private void cancelbook_Click(object sender, EventArgs e)
            {
            bookingID = txtBookingID.Text;
            string result = CancelBooking();
            MessageBox.Show(result);
        }
        
    }
}
