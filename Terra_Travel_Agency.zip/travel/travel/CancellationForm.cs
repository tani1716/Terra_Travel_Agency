﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace travel
{
    public partial class CancellationForm : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\hpara\\source\\repos\\travel\\travel\\terratraveldb.mdf;Integrated Security=True";

        public CancellationForm()
        {
            InitializeComponent();
        }

        private void CancellationForm_Load(object sender, EventArgs e)
        {

        }

        // Method to cancel a booking without using parameters
        private string CancelBooking()
        {
            string bookingID = txtBookingID.Text; // Get the booking ID directly from the text box

            // Check if the booking ID is valid
            if (string.IsNullOrWhiteSpace(bookingID))
            {
                return "Please enter a valid Booking ID.";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // Constructing the query dynamically using the booking ID
                    string query = "DELETE FROM Bookings_tbl WHERE BookingID = '" + bookingID + "'"; // Assuming BookingID is the column name

                    SqlCommand command = new SqlCommand(query, connection);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return "Booking cancelled successfully.";
                    }
                    else
                    {
                        return "Booking not found or already cancelled.";
                    }
                }
                catch (Exception ex)
                {
                    return "Error cancelling booking: " + ex.Message;
                }
            }
        }

        private void btnCancelBooking_Click(object sender, EventArgs e)
        {
            // Call the CancelBooking method and display the result
            string result = CancelBooking();
            MessageBox.Show(result);
        }
    }
 }