﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class TrainBookingForm : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";


        public TrainBookingForm()
        {
            InitializeComponent();
            LoadRouteComboBoxes();

            // Add event handlers for when the user selects an item
            comboBoxTrainName.SelectedIndexChanged += comboBoxTrainName_SelectedIndexChanged;

        }



        // Load train names when the form loads
        private void TrainBookingForm_Load(object sender, EventArgs e)
        {
        }

        private void UpdateRoute()
        {
            string fromCity = comboBoxRouteFrom.SelectedItem?.ToString();
            string toCity = comboBoxRouteTo.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(fromCity) && !string.IsNullOrEmpty(toCity))
            {
                labelArrival.Text = $"Route: {fromCity} - {toCity}";
            }
        }


        private void btnback_Click(object sender, EventArgs e)
        {
          
        }

        private void btnback_Click_1(object sender, EventArgs e)
        {

        }

        private void btnback_Click_2(object sender, EventArgs e)
        {
            
        }

        private void LoadRouteComboBoxes()
        {
            // Populate the combo boxes with data from Train_management_tbl
            string query = "SELECT DISTINCT RouteFrom, RouteTo, TrainName, DepartureTime, ArrivalTime, PricePerSeat FROM Train_management_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                try
                {
                    connection.Open();
                    adapter.Fill(dataTable);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        comboBoxRouteFrom.Items.Add(row["RouteFrom"].ToString());
                        comboBoxRouteTo.Items.Add(row["RouteTo"].ToString());
                        comboBoxTrainName.Items.Add(row["TrainName"].ToString());
                        comboBoxDeparture.Items.Add(Convert.ToDateTime(row["DepartureTime"]).ToString("HH:mm"));
                        comboBoxArrival.Items.Add(Convert.ToDateTime(row["ArrivalTime"]).ToString("HH:mm"));
                    }

                    // Store the entire dataTable for later use (price lookup)
                    comboBoxTrainName.Tag = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading routes: " + ex.Message);
                }
            }

            // Add event handlers for when the user selects a train and route
            comboBoxTrainName.SelectedIndexChanged += comboBoxTrainName_SelectedIndexChanged;
            comboBoxRouteFrom.SelectedIndexChanged += comboBoxTrainName_SelectedIndexChanged;
            comboBoxRouteTo.SelectedIndexChanged += comboBoxTrainName_SelectedIndexChanged;
        }



        private bool ValidateBooking()
        {
            // Simple validation example
            if (string.IsNullOrEmpty(comboBoxRouteFrom.Text) ||
                string.IsNullOrEmpty(comboBoxRouteTo.Text) ||
                string.IsNullOrEmpty(comboBoxTrainName.Text) ||
                string.IsNullOrEmpty(textBoxCustomerName.Text) ||
                string.IsNullOrEmpty(textBoxNumberOfSeats.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return false;
            }
            return true;
        }




        private void AddBooking()
        {
            try
            {
                int numberOfSeats = int.Parse(textBoxNumberOfSeats.Text);
                decimal pricePerSeat = decimal.Parse(textBoxPricePerSeat.Text);
                decimal totalAmount = pricePerSeat * numberOfSeats;

                string query = "INSERT INTO TrainBooking_tbl (CustomerName, RouteFrom, RouteTo, TrainName, DepartureTime, ArrivalTime, NumberOfSeats, PricePerSeat, TotalAmount) " +
                               "VALUES ('" + textBoxCustomerName.Text + "', '" + comboBoxRouteFrom.Text + "', '" + comboBoxRouteTo.Text + "', '" +
                               comboBoxTrainName.Text + "', '" + dateTimePickerDeparture.Value.ToString("yyyy-MM-dd HH:mm:ss") + "', '" +
                               dateTimePickerArrival.Value.ToString("yyyy-MM-dd HH:mm:ss") + "', " + numberOfSeats + ", " + pricePerSeat + ", " + totalAmount + ")";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Booking added successfully!");
                        LoadBookingData(); // Refresh DataGridView
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding booking: " + ex.Message);
            }
        }



        private void CalculateTotalAmount()
        {
            int numberOfSeats;
            decimal pricePerSeat;

            // Check if the inputs are valid
            if (int.TryParse(textBoxNumberOfSeats.Text, out numberOfSeats) &&
                decimal.TryParse(textBoxPricePerSeat.Text, out pricePerSeat))
            {
                // Calculate total amount
                decimal totalAmount = numberOfSeats * pricePerSeat;
                textBoxTotalAmount.Text = totalAmount.ToString("0.00"); // Display the total amount
            }
            else
            {
                textBoxTotalAmount.Text = "0.00"; // Default value if input is invalid
            }
        }


        private void LoadBookingData()
        {
            // Load data from TrainBooking_tbl into DataGridView
            string query = "SELECT CustomerName, RouteFrom, RouteTo, TrainName, DepartureTime, ArrivalTime, NumberOfSeats, PricePerSeat, TotalAmount FROM TrainBooking_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                try
                {
                    adapter.Fill(dataTable);
                    dataGridViewBookings.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading booking data: " + ex.Message);
                }
            }
        }



        private void btnOk_Click(object sender, EventArgs e)
        {
            if (ValidateBooking())
            {
                AddBooking();
            }
        }

    



        private void pictureBox9_Click(object sender, EventArgs e)
        {
            BookingForm bookingForm = new BookingForm();
            bookingForm.Show(); // Show the booking form
            this.Hide(); // Hide the current form
        }

        private void comboBoxTrainName_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Ensure a train, route from, and route to are all selected
            if (comboBoxTrainName.SelectedItem != null && comboBoxRouteFrom.SelectedItem != null && comboBoxRouteTo.SelectedItem != null)
            {
                string selectedTrain = comboBoxTrainName.SelectedItem.ToString();
                string selectedRouteFrom = comboBoxRouteFrom.SelectedItem.ToString();
                string selectedRouteTo = comboBoxRouteTo.SelectedItem.ToString();

                // Get the DataTable stored in Tag
                DataTable trainData = (DataTable)comboBoxTrainName.Tag;

                foreach (DataRow row in trainData.Rows)
                {
                    if (row["TrainName"].ToString() == selectedTrain &&
                        row["RouteFrom"].ToString() == selectedRouteFrom &&
                        row["RouteTo"].ToString() == selectedRouteTo)
                    {
                        decimal pricePerSeat = Convert.ToDecimal(row["PricePerSeat"]);
                        textBoxPricePerSeat.Text = pricePerSeat.ToString("F2");
                        break;
                    }
                }
            }
        }

            private void textBoxSeats_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void comboBoxSeats_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxNumberOfSeats_TextChanged(object sender, EventArgs e)
        {
            CalculateTotalAmount();

        }
    }
}
