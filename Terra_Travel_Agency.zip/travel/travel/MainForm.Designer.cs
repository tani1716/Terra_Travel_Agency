﻿
namespace travel
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnHotelBooking = new System.Windows.Forms.Button();
            this.btnManageTrains = new System.Windows.Forms.Button();
            this.btnBookings = new System.Windows.Forms.Button();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btnUserAccount = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnBookingSearch = new System.Windows.Forms.Button();
            this.btnCancellation = new System.Windows.Forms.Button();
            this.btnSchedule = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.payment = new System.Windows.Forms.Label();
            this.hotel = new System.Windows.Forms.Label();
            this.train = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.home = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackColor = System.Drawing.Color.Tomato;
            this.btnCustomer.Location = new System.Drawing.Point(543, 370);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(125, 57);
            this.btnCustomer.TabIndex = 0;
            this.btnCustomer.Text = "Customer";
            this.btnCustomer.UseVisualStyleBackColor = false;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // btnHotelBooking
            // 
            this.btnHotelBooking.BackColor = System.Drawing.Color.Tomato;
            this.btnHotelBooking.Location = new System.Drawing.Point(350, 370);
            this.btnHotelBooking.Name = "btnHotelBooking";
            this.btnHotelBooking.Size = new System.Drawing.Size(125, 57);
            this.btnHotelBooking.TabIndex = 1;
            this.btnHotelBooking.Text = "Hotel Booking";
            this.btnHotelBooking.UseVisualStyleBackColor = false;
            this.btnHotelBooking.Click += new System.EventHandler(this.btnManageHotels_Click);
            // 
            // btnManageTrains
            // 
            this.btnManageTrains.BackColor = System.Drawing.Color.Tomato;
            this.btnManageTrains.Location = new System.Drawing.Point(350, 248);
            this.btnManageTrains.Name = "btnManageTrains";
            this.btnManageTrains.Size = new System.Drawing.Size(125, 57);
            this.btnManageTrains.TabIndex = 2;
            this.btnManageTrains.Text = "Train Booking";
            this.btnManageTrains.UseVisualStyleBackColor = false;
            this.btnManageTrains.Click += new System.EventHandler(this.btnManageTrains_Click);
            // 
            // btnBookings
            // 
            this.btnBookings.BackColor = System.Drawing.Color.Tomato;
            this.btnBookings.Location = new System.Drawing.Point(350, 137);
            this.btnBookings.Name = "btnBookings";
            this.btnBookings.Size = new System.Drawing.Size(125, 57);
            this.btnBookings.TabIndex = 3;
            this.btnBookings.Text = "Booking";
            this.btnBookings.UseVisualStyleBackColor = false;
            this.btnBookings.Click += new System.EventHandler(this.btnBookings_Click);
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.BackColor = System.Drawing.Color.Tomato;
            this.btnCheckOut.Location = new System.Drawing.Point(350, 482);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(125, 57);
            this.btnCheckOut.TabIndex = 4;
            this.btnCheckOut.Text = "Check-Out";
            this.btnCheckOut.UseVisualStyleBackColor = false;
            this.btnCheckOut.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.BackColor = System.Drawing.Color.Tomato;
            this.btnPayment.Location = new System.Drawing.Point(552, 137);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(125, 57);
            this.btnPayment.TabIndex = 6;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnLoyaltyProgram_Click);
            // 
            // btnUserAccount
            // 
            this.btnUserAccount.BackColor = System.Drawing.Color.Tomato;
            this.btnUserAccount.Location = new System.Drawing.Point(543, 248);
            this.btnUserAccount.Name = "btnUserAccount";
            this.btnUserAccount.Size = new System.Drawing.Size(125, 57);
            this.btnUserAccount.TabIndex = 7;
            this.btnUserAccount.Text = "User Account";
            this.btnUserAccount.UseVisualStyleBackColor = false;
            this.btnUserAccount.Click += new System.EventHandler(this.btnSystemLogs_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.LightSalmon;
            this.btnConnect.Location = new System.Drawing.Point(712, 438);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(92, 49);
            this.btnConnect.TabIndex = 8;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.BackColor = System.Drawing.Color.LightSalmon;
            this.btnInsert.Location = new System.Drawing.Point(983, 285);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(94, 49);
            this.btnInsert.TabIndex = 9;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = false;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnBookingSearch
            // 
            this.btnBookingSearch.BackColor = System.Drawing.Color.Tomato;
            this.btnBookingSearch.Location = new System.Drawing.Point(712, 317);
            this.btnBookingSearch.Name = "btnBookingSearch";
            this.btnBookingSearch.Size = new System.Drawing.Size(125, 57);
            this.btnBookingSearch.TabIndex = 12;
            this.btnBookingSearch.Text = "Booking Search";
            this.btnBookingSearch.UseVisualStyleBackColor = false;
            this.btnBookingSearch.Click += new System.EventHandler(this.btnBookingSearch_Click);
            // 
            // btnCancellation
            // 
            this.btnCancellation.BackColor = System.Drawing.Color.Tomato;
            this.btnCancellation.Location = new System.Drawing.Point(552, 482);
            this.btnCancellation.Name = "btnCancellation";
            this.btnCancellation.Size = new System.Drawing.Size(125, 57);
            this.btnCancellation.TabIndex = 13;
            this.btnCancellation.Text = "Cancellation";
            this.btnCancellation.UseVisualStyleBackColor = false;
            this.btnCancellation.Click += new System.EventHandler(this.btnCancellation_Click);
            // 
            // btnSchedule
            // 
            this.btnSchedule.BackColor = System.Drawing.Color.Tomato;
            this.btnSchedule.Location = new System.Drawing.Point(712, 215);
            this.btnSchedule.Name = "btnSchedule";
            this.btnSchedule.Size = new System.Drawing.Size(125, 57);
            this.btnSchedule.TabIndex = 15;
            this.btnSchedule.Text = "Schedule";
            this.btnSchedule.UseVisualStyleBackColor = false;
            this.btnSchedule.Click += new System.EventHandler(this.btnSchedule_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 606);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 17);
            this.label5.TabIndex = 38;
            this.label5.Text = "logout";
            // 
            // payment
            // 
            this.payment.AutoSize = true;
            this.payment.Location = new System.Drawing.Point(89, 505);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(74, 17);
            this.payment.TabIndex = 37;
            this.payment.Text = "PAYMENT";
            this.payment.Click += new System.EventHandler(this.payment_Click);
            // 
            // hotel
            // 
            this.hotel.AutoSize = true;
            this.hotel.Location = new System.Drawing.Point(89, 410);
            this.hotel.Name = "hotel";
            this.hotel.Size = new System.Drawing.Size(123, 17);
            this.hotel.TabIndex = 36;
            this.hotel.Text = "HOTEL BOOKING";
            this.hotel.Click += new System.EventHandler(this.hotel_Click);
            // 
            // train
            // 
            this.train.AutoSize = true;
            this.train.Location = new System.Drawing.Point(88, 317);
            this.train.Name = "train";
            this.train.Size = new System.Drawing.Size(117, 17);
            this.train.TabIndex = 35;
            this.train.Text = "TRAIN BOOKING";
            this.train.Click += new System.EventHandler(this.train_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 215);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 34;
            this.label1.Text = "Login";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // home
            // 
            this.home.AutoSize = true;
            this.home.BackColor = System.Drawing.Color.PeachPuff;
            this.home.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home.ForeColor = System.Drawing.Color.LightCoral;
            this.home.Location = new System.Drawing.Point(575, 30);
            this.home.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(210, 69);
            this.home.TabIndex = 40;
            this.home.Text = "HOME";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::travel.Properties.Resources.flight_management;
            this.pictureBox7.Location = new System.Drawing.Point(871, 99);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(259, 440);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 39;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::travel.Properties.Resources.l1;
            this.pictureBox6.Location = new System.Drawing.Point(12, 590);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 33;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::travel.Properties.Resources.pay;
            this.pictureBox5.Location = new System.Drawing.Point(11, 485);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 32;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::travel.Properties.Resources.hotel;
            this.pictureBox4.Location = new System.Drawing.Point(11, 388);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 31;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::travel.Properties.Resources.trainmanage;
            this.pictureBox3.Location = new System.Drawing.Point(11, 295);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::travel.Properties.Resources.login1;
            this.pictureBox2.Location = new System.Drawing.Point(12, 193);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::travel.Properties.Resources.Travel_agency__1__removebg_preview__2_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(159, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.home);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.hotel);
            this.Controls.Add(this.train);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnSchedule);
            this.Controls.Add(this.btnCancellation);
            this.Controls.Add(this.btnBookingSearch);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.btnUserAccount);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnCheckOut);
            this.Controls.Add(this.btnBookings);
            this.Controls.Add(this.btnManageTrains);
            this.Controls.Add(this.btnHotelBooking);
            this.Controls.Add(this.btnCustomer);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Button btnHotelBooking;
        private System.Windows.Forms.Button btnManageTrains;
        private System.Windows.Forms.Button btnBookings;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.Button btnUserAccount;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnBookingSearch;
        private System.Windows.Forms.Button btnCancellation;
        private System.Windows.Forms.Button btnSchedule;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label payment;
        private System.Windows.Forms.Label hotel;
        private System.Windows.Forms.Label train;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label home;
    }
}