﻿
namespace travel
{
    partial class ScheduleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cmbRoute = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpTravelDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvTrainSchedule = new System.Windows.Forms.DataGridView();
            this.btnCheckSchedule = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.payment = new System.Windows.Forms.Label();
            this.hotel = new System.Windows.Forms.Label();
            this.train = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.schedule = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrainSchedule)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(413, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Train Schedule";
            // 
            // cmbRoute
            // 
            this.cmbRoute.FormattingEnabled = true;
            this.cmbRoute.Location = new System.Drawing.Point(518, 382);
            this.cmbRoute.Name = "cmbRoute";
            this.cmbRoute.Size = new System.Drawing.Size(121, 24);
            this.cmbRoute.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(413, 382);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "route";
            // 
            // dtpTravelDate
            // 
            this.dtpTravelDate.Location = new System.Drawing.Point(518, 454);
            this.dtpTravelDate.Name = "dtpTravelDate";
            this.dtpTravelDate.Size = new System.Drawing.Size(200, 22);
            this.dtpTravelDate.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(413, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "travel date";
            // 
            // dgvTrainSchedule
            // 
            this.dgvTrainSchedule.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dgvTrainSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTrainSchedule.Location = new System.Drawing.Point(829, 140);
            this.dgvTrainSchedule.Name = "dgvTrainSchedule";
            this.dgvTrainSchedule.RowHeadersWidth = 51;
            this.dgvTrainSchedule.RowTemplate.Height = 24;
            this.dgvTrainSchedule.Size = new System.Drawing.Size(310, 194);
            this.dgvTrainSchedule.TabIndex = 6;
            // 
            // btnCheckSchedule
            // 
            this.btnCheckSchedule.Location = new System.Drawing.Point(754, 577);
            this.btnCheckSchedule.Name = "btnCheckSchedule";
            this.btnCheckSchedule.Size = new System.Drawing.Size(87, 75);
            this.btnCheckSchedule.TabIndex = 7;
            this.btnCheckSchedule.Text = "CHECK SCEDULE";
            this.btnCheckSchedule.UseVisualStyleBackColor = true;
            this.btnCheckSchedule.Click += new System.EventHandler(this.btnCheckSchedule_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 606);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 17);
            this.label5.TabIndex = 49;
            this.label5.Text = "logout";
            // 
            // payment
            // 
            this.payment.AutoSize = true;
            this.payment.Location = new System.Drawing.Point(89, 505);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(74, 17);
            this.payment.TabIndex = 48;
            this.payment.Text = "PAYMENT";
            // 
            // hotel
            // 
            this.hotel.AutoSize = true;
            this.hotel.Location = new System.Drawing.Point(89, 410);
            this.hotel.Name = "hotel";
            this.hotel.Size = new System.Drawing.Size(123, 17);
            this.hotel.TabIndex = 47;
            this.hotel.Text = "HOTEL BOOKING";
            // 
            // train
            // 
            this.train.AutoSize = true;
            this.train.Location = new System.Drawing.Point(88, 317);
            this.train.Name = "train";
            this.train.Size = new System.Drawing.Size(117, 17);
            this.train.TabIndex = 46;
            this.train.Text = "TRAIN BOOKING";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 215);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 17);
            this.label2.TabIndex = 45;
            this.label2.Text = "Login";
            // 
            // schedule
            // 
            this.schedule.AutoSize = true;
            this.schedule.BackColor = System.Drawing.Color.PeachPuff;
            this.schedule.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.schedule.ForeColor = System.Drawing.Color.LightCoral;
            this.schedule.Location = new System.Drawing.Point(476, 48);
            this.schedule.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.schedule.Name = "schedule";
            this.schedule.Size = new System.Drawing.Size(355, 69);
            this.schedule.TabIndex = 50;
            this.schedule.Text = "SCHEDULE";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::travel.Properties.Resources.l1;
            this.pictureBox6.Location = new System.Drawing.Point(12, 590);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 44;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::travel.Properties.Resources.pay;
            this.pictureBox5.Location = new System.Drawing.Point(11, 485);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 54);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 43;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::travel.Properties.Resources.hotel;
            this.pictureBox4.Location = new System.Drawing.Point(11, 388);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 42;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::travel.Properties.Resources.trainmanage;
            this.pictureBox3.Location = new System.Drawing.Point(11, 295);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 41;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::travel.Properties.Resources.login1;
            this.pictureBox2.Location = new System.Drawing.Point(12, 193);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::travel.Properties.Resources.Travel_agency__1__removebg_preview__2_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(159, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::travel.Properties.Resources.back;
            this.pictureBox7.Location = new System.Drawing.Point(1004, 581);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(71, 60);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 75;
            this.pictureBox7.TabStop = false;
            // 
            // ScheduleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.schedule);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.hotel);
            this.Controls.Add(this.train);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCheckSchedule);
            this.Controls.Add(this.dgvTrainSchedule);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpTravelDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbRoute);
            this.Controls.Add(this.label1);
            this.Name = "ScheduleForm";
            this.Text = "ScheduleForm";
            this.Load += new System.EventHandler(this.ScheduleForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrainSchedule)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbRoute;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpTravelDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvTrainSchedule;
        private System.Windows.Forms.Button btnCheckSchedule;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label payment;
        private System.Windows.Forms.Label hotel;
        private System.Windows.Forms.Label train;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label schedule;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}