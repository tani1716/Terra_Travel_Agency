﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace travel
{
    public partial class SystemLogsForm : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hpara\source\repos\travel\travel\terratraveldb.mdf;Integrated Security=True";


        public SystemLogsForm()
        {
            InitializeComponent();
            this.Load += SystemLogsForm_Load; // Ensure Load event is wired
            btnViewLogs.Click += btnViewLogs_Click; // Event handler for ViewLogs button
        }

        private void SystemLogsForm_Load(object sender, EventArgs e)
        {
            LoadLogsData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnViewLogs_Click(object sender, EventArgs e)
        {
            LoadLogsData(); // Load logs when View Logs button is clicked
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadLogsData()
        {
            string query = "SELECT LogID, LogDate FROM SystemLogs_info_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();

                try
                {
                    connection.Open();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to the DataGridView
                    dataGridViewLogs.AutoGenerateColumns = true;
                    dataGridViewLogs.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading logs data: " + ex.Message);
                }
            }
        }
    }
}
  
