﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace travel
{
    public partial class adminsettings : Form
    {
        public adminsettings()
        {
            InitializeComponent();
        }

        private void btnSaveSettings_Click(object sender, EventArgs e)
        {

        }
    

        private void button1_Click(object sender, EventArgs e)
        {
            TrainManagementForm trainManagementForm = new TrainManagementForm();
            trainManagementForm.Show(); // Or ShowDialog() for a modal window
        }

        private void btnstaff_Click(object sender, EventArgs e)
        {
            StaffManagementForm staffManagementForm = new StaffManagementForm();
            staffManagementForm.Show(); // Use Show() to open non-modal, or ShowDialog() for modal
        }

        private void btnsystemlog_Click(object sender, EventArgs e)
        {
            SystemLogsForm systemLogsForm = new SystemLogsForm();
            systemLogsForm.Show(); // Use Show() to open non-modal, or ShowDialog() for modal
        }

        private void adminsettings_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            login Login = new login();
            Login.Show(); 
        }

        private void label2_Click(object sender, EventArgs e)
        {
            TrainManagementForm trainManagementForm = new TrainManagementForm();
            trainManagementForm.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            StaffManagementForm staffManagementForm = new StaffManagementForm();
            staffManagementForm.Show(); // Use Show() to open non-modal, or ShowDialog() for modal
        }

        private void label4_Click(object sender, EventArgs e)
        {
            SystemLogsForm systemLogsForm = new SystemLogsForm();
            systemLogsForm.Show(); // Use Show() to open non-modal, or ShowDialog() for modal
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
